# shellcheck shell=ash
#
# Module: sing_box_config_manager.sh
#
# Purpose:
#   This script provides a set of helper functions to simplify creation and management
#   of sing-box configuration.
#
# Conventions:
#   - All functions are prefixed with: sing_box_cm_*
#   - "cm" stands for "config manager", shortened by convention
#
# Usage:
#   Include this script in your ash script with:
#     . /usr/lib/netshift/sing_box_config_manager.sh
#
#   After that, sing_box_cm_* functions are available for generating
#   and modifying sing-box JSON configuration.

SERVICE_TAG="__service_tag"

#######################################
# Configure the logging section of a sing-box JSON configuration.
# Arguments:
#   config: string, JSON configuration
#   disabled: boolean, true to disable logging
#   level: string, log level. One of: trace debug info warn error fatal panic.
#   timestamp: boolean, true to include timestamps
# Outputs:
#   Writes updated JSON configuration to stdout
# Example:
#   CONFIG=$(sing_box_cm_configure_log "$CONFIG" false "info" true)
#######################################
sing_box_cm_configure_log() {
    local config="$1"
    local disabled="$2"
    local level="$3"
    local timestamp="$4"

    echo "$config" | jq \
        --argjson disabled "$disabled" \
        --arg level "$level" \
        --argjson timestamp "$timestamp" \
        '.log = {
			disabled: $disabled,
			level: $level,
			timestamp: $timestamp
		}'
}

#######################################
# Configure the DNS section of a sing-box JSON configuration.
# Arguments:
#   config: string (JSON), sing-box configuration to modify
#   final: string, default dns server tag
#   strategy: string, default domain strategy for resolving the domain names
#   independent_cache: boolean, whether to use an independent DNS cache; empty leaves the field
#     out (sing-box 1.14 deprecates it, 1.16 rejects a configuration that has it)
# Outputs:
#   Writes updated JSON configuration to stdout
# Example:
#   CONFIG=$(sing_box_cm_configure_dns "$CONFIG" "direct-out" "ipv4_only" true)
#######################################
sing_box_cm_configure_dns() {
    local config="$1"
    local final="$2"
    local strategy="$3"
    local independent_cache="$4"

    echo "$config" | jq \
        --arg final "$final" \
        --arg strategy "$strategy" \
        --arg independent_cache "$independent_cache" \
        '.dns = ({
			servers: (.dns.servers // []),
			rules: (.dns.rules // []),
			final: $final,
			strategy: $strategy
		} + (if $independent_cache == "" then {} else {independent_cache: ($independent_cache == "true")} end))'

}

#######################################
# Set the EDNS Client Subnet (ECS, RFC 7871) of the DNS section of a sing-box
# JSON configuration. The value is an IP address or IP prefix that sing-box
# appends as an edns0-subnet OPT record to every DNS query (a bare address gets
# /32 or /128 appended), so geo-distributed services resolve to the node
# closest to the client. It is a single top-level DNS field, which sing-box
# applies to every server unless a server overrides it.
# Callers MUST validate the value and only call this for a non-empty option: an
# absent/empty option must leave the DNS section untouched, and sing-box
# rejects the whole configuration for a malformed prefix.
# Arguments:
#   config: string (JSON), sing-box configuration to modify
#   client_subnet: string, IP address or IP prefix, e.g. 203.0.113.0/24
# Outputs:
#   Writes updated JSON configuration to stdout
# Example:
#   CONFIG=$(sing_box_cm_set_dns_client_subnet "$CONFIG" "203.0.113.0/24")
#######################################
sing_box_cm_set_dns_client_subnet() {
    local config="$1"
    local client_subnet="$2"

    echo "$config" | jq \
        --arg client_subnet "$client_subnet" \
        '.dns.client_subnet = $client_subnet'
}

#######################################
# Add a UDP DNS server to the DNS section of a sing-box JSON configuration.
# Arguments:
#   config: string (JSON), sing-box configuration to modify
#   tag: string, identifier for the DNS server
#   server_address: string, IP address or hostname of the DNS server
#   server_port: string or integer, port of the DNS server
#   domain_resolver: string, domain resolver to use for resolving domain names (optional)
#   detour: string, tag of the upstream outbound (optional)
# Outputs:
#   Writes updated JSON configuration to stdout
# Example:
#   CONFIG=$(sing_box_cm_add_udp_dns_server "$CONFIG" "udp-server" "8.8.8.8" 53)
#######################################
sing_box_cm_add_udp_dns_server() {
    local config="$1"
    local tag="$2"
    local server_address="$3"
    local server_port="$4"
    local domain_resolver="$5"
    local detour="$6"

    echo "$config" | jq \
        --arg tag "$tag" \
        --arg server_address "$server_address" \
        --arg server_port "$server_port" \
        --arg domain_resolver "$domain_resolver" \
        --arg detour "$detour" \
        '.dns.servers += [(
            {
                type: "udp",
                tag: $tag,
                server: $server_address,
                server_port: ($server_port | tonumber)
		    }
            + (if $detour != "" then { detour: $detour } else {} end)
		    + (if $domain_resolver != "" then { domain_resolver: $domain_resolver } else {} end)
		)]'
}

#######################################
# Add a TLS DNS server to the DNS section of a sing-box JSON configuration.
# Arguments:
#   config: string (JSON), sing-box configuration to modify
#   tag: string, identifier for the DNS server
#   server_address: string, IP address or hostname of the DNS server
#   server_port: string or integer, port of the DNS server
#   domain_resolver: string, domain resolver to use for resolving domain names (optional)
#   detour: string, tag of the upstream outbound (optional)
# Outputs:
#   Writes updated JSON configuration to stdout
# Example:
#   CONFIG=$(sing_box_cm_add_tls_dns_server "$CONFIG" "dot-server" "1.1.1.1" 853)
#######################################
sing_box_cm_add_tls_dns_server() {
    local config="$1"
    local tag="$2"
    local server_address="$3"
    local server_port="$4"
    local domain_resolver="$5"
    local detour="$6"

    echo "$config" | jq \
        --arg tag "$tag" \
        --arg server_address "$server_address" \
        --arg server_port "$server_port" \
        --arg domain_resolver "$domain_resolver" \
        --arg detour "$detour" \
        '.dns.servers += [(
            {
			    type: "tls",
			    tag: $tag,
			    server: $server_address,
			    server_port: ($server_port | tonumber)
		    }
            + (if $detour != "" then { detour: $detour } else {} end)
		    + (if $domain_resolver != "" then { domain_resolver: $domain_resolver } else {} end)
		)]'
}

#######################################
# Add an HTTPS DNS server to the DNS section of a sing-box JSON configuration.
# Arguments:
#   config: string (JSON), sing-box configuration to modify
#   tag: string, identifier for the DNS server
#   server_address: string, IP address or hostname of the DNS server
#   server_port: string or integer, port of the DNS server
#   path: string, URL path for HTTPS DNS requests (optional)
#   headers: string, additional headers for HTTPS DNS requests (optional)
#   domain_resolver: string, domain resolver to use for resolving domain names (optional)
#   detour: string, tag of the upstream outbound (optional)
# Outputs:
#   Writes updated JSON configuration to stdout
# Example:
#   CONFIG=$(sing_box_cm_add_https_dns_server "$CONFIG" "doh-server" "1.1.1.1" 443)
#######################################
sing_box_cm_add_https_dns_server() {
    local config="$1"
    local tag="$2"
    local server_address="$3"
    local server_port="$4"
    local path="$5"
    local headers="$6"
    local domain_resolver="$7"
    local detour="$8"

    echo "$config" | jq \
        --arg tag "$tag" \
        --arg server_address "$server_address" \
        --arg server_port "$server_port" \
        --arg path "$path" \
        --arg headers "$headers" \
        --arg domain_resolver "$domain_resolver" \
        --arg detour "$detour" \
        '.dns.servers += [(
			{
				type: "https",
				tag: $tag,
				server: $server_address,
				server_port: ($server_port |tonumber)
			}
			+ (if $path != "" then { path: $path } else {} end)
			+ (if $headers != "" then { headers: $headers } else {} end)
            + (if $detour != "" then { detour: $detour } else {} end)
			+ (if $domain_resolver != "" then { domain_resolver: $domain_resolver } else {} end)
		)]'
}

#######################################
# Add a TCP, HTTP/3 or QUIC DNS server to the DNS section of a sing-box JSON
# configuration (the types that have no dedicated helper above).
# Arguments:
#   config: string (JSON), sing-box configuration to modify
#   type: string, sing-box DNS server type: tcp, h3 or quic
#   tag: string, identifier for the DNS server
#   server_address: string, IP address or hostname of the DNS server
#   server_port: string or integer, port of the DNS server
#   path: string, URL path (h3 only, optional)
#   domain_resolver: string, domain resolver to use for resolving domain names (optional)
#   detour: string, tag of the upstream outbound (optional)
# Outputs:
#   Writes updated JSON configuration to stdout
# Example:
#   CONFIG=$(sing_box_cm_add_other_dns_server "$CONFIG" "quic" "doq-server" "dns.adguard-dns.com" 853)
#######################################
sing_box_cm_set_outbounds_detour() {
    local config="$1"
    local section_tag="$2"
    local target_tag="$3"
    local exclude="${4:-[]}"
    local raw="${5:-0}"

    if [ "$raw" = "1" ] &&
        ! echo "$config" | jq -e --arg tag "$section_tag" \
            '[.outbounds[] | select(.tag == $tag) | .type] | all(. != "selector" and . != "urltest")' > /dev/null 2>&1; then
        echo "$config"
        return 3
    fi

    echo "$config" | jq \
        --arg section_tag "$section_tag" \
        --arg target_tag "$target_tag" \
        --argjson exclude "$exclude" \
        '(.outbounds | map({key: .tag, value: .}) | from_entries) as $by
        | def leaves($tag; $depth):
            ($by[$tag] // null) as $o
            | if $o == null or $depth > 8 then empty
              elif ((["selector", "urltest"] | index($o.type)) != null)
              then ($o.outbounds[]? | leaves(.; $depth + 1))
              else $tag end;
        ([leaves($section_tag; 0)] | unique) as $mine
        | ([leaves($target_tag; 0)] | unique) as $theirs
        | .outbounds |= map(
            if ((.tag as $t | $mine | index($t)) != null)
               and ((.tag as $t | $theirs | index($t)) == null)
               and ((.tag as $t | $exclude | index($t)) == null)
               and (has("detour") | not)
            then . + { detour: $target_tag }
            else . end)'
}
sing_box_cm_add_final_reject_rule() {
    local config="$1"
    local tag="$2"

    echo "$config" | jq \
        --arg service_tag "$SERVICE_TAG" \
        --arg tag "$tag" \
        '.route.rules += [{
            action: "reject",
            $service_tag: $tag
        }]'
}
sing_box_cm_add_other_dns_server() {
    local config="$1"
    local type="$2"
    local tag="$3"
    local server_address="$4"
    local server_port="$5"
    local path="$6"
    local domain_resolver="$7"
    local detour="$8"

    echo "$config" | jq \
        --arg type "$type" \
        --arg tag "$tag" \
        --arg server_address "$server_address" \
        --arg server_port "$server_port" \
        --arg path "$path" \
        --arg domain_resolver "$domain_resolver" \
        --arg detour "$detour" \
        '.dns.servers += [(
            {
                type: $type,
                tag: $tag,
                server: $server_address,
                server_port: ($server_port | tonumber)
            }
            + (if $type == "h3" and $path != "" then { path: $path } else {} end)
            + (if $detour != "" then { detour: $detour } else {} end)
            + (if $domain_resolver != "" then { domain_resolver: $domain_resolver } else {} end)
        )]'
}

#######################################
# Add an `evaluate` DNS rule: send the query to a server and keep the response
# (under a tag) for later rules, without ending rule evaluation. sing-box >= 1.14.0.
# Arguments:
#   config: string (JSON), sing-box configuration to modify
#   server: string, tag of the DNS server to query
#   response_tag: string, tag the evaluated response is saved under
#   timeout: string, query timeout (e.g. "2s")
# Outputs:
#   Writes updated JSON configuration to stdout
#######################################
sing_box_cm_add_dns_evaluate_rule() {
    local config="$1"
    local server="$2"
    local response_tag="$3"
    local timeout="$4"

    echo "$config" | jq \
        --arg server "$server" \
        --arg response_tag "$response_tag" \
        --arg timeout "$timeout" \
        '.dns.rules += [{
            action: "evaluate",
            server: $server,
            tag: $response_tag,
            timeout: $timeout
        }]'
}

#######################################
# Add a `respond` DNS rule: when the evaluated response saved under a tag has the
# given rcode, return it and end rule evaluation. sing-box >= 1.14.0.
# Arguments:
#   config: string (JSON), sing-box configuration to modify
#   response_tag: string, tag of the evaluated response to match and return
#   rcode: string, response code to match (NOERROR, NXDOMAIN, ...)
#   race: string, "true" makes it a race rule (the first matching race rule wins
#         while the other queries are still running); anything else is in order
# Outputs:
#   Writes updated JSON configuration to stdout
#######################################
sing_box_cm_add_dns_respond_rule() {
    local config="$1"
    local response_tag="$2"
    local rcode="$3"
    local race="${4:-false}"

    echo "$config" | jq \
        --arg response_tag "$response_tag" \
        --arg rcode "$rcode" \
        --arg race "$race" \
        '.dns.rules += [(
            {
                match_response: $response_tag,
                response_rcode: $rcode,
                action: "respond"
            }
            + (if $race == "true" then { race: true } else {} end)
        )]'
}

#######################################
# Set the DNS server queries fall back to when no DNS rule answers them.
# Arguments:
#   config: string (JSON), sing-box configuration to modify
#   final: string, tag of the DNS server
# Outputs:
#   Writes updated JSON configuration to stdout
#######################################
sing_box_cm_set_dns_final() {
    local config="$1"
    local final="$2"

    echo "$config" | jq --arg final "$final" '.dns.final = $final'
}

#######################################
# Add a FakeIP DNS server to the DNS section of a sing-box JSON configuration.
# Arguments:
#   config: string (JSON), sing-box configuration to modify
#   tag: string, identifier for the DNS server
#   inet4_range: string, IPv4 range used for fake IP mapping
# Outputs:
#   Writes updated JSON configuration to stdout
# Example:
#   CONFIG=$(sing_box_cm_add_fakeip_dns_server "$CONFIG" "fakeip-server" "198.18.0.0/15")
#######################################
sing_box_cm_add_fakeip_dns_server() {
    local config="$1"
    local tag="$2"
    local inet4_range="$3"
    local inet6_range="$4"

    echo "$config" | jq \
        --arg tag "$tag" \
        --arg inet4_range "$inet4_range" \
        --arg inet6_range "$inet6_range" \
        '.dns.servers += [(
            {
                type: "fakeip",
                tag: $tag,
                inet4_range: $inet4_range
            }
            + (if $inet6_range != "" then { inet6_range: $inet6_range } else {} end)
        )]'
}

#######################################
# Add a DNS routing rule to the DNS section of a sing-box JSON configuration.
# Arguments:
#   config: string (JSON), sing-box configuration to modify
#   server: string, target DNS server for the rule
#   tag: string, identifier for the route rule
# Outputs:
#   Writes updated JSON configuration to stdout
# Example:
#   CONFIG=$(sing_box_cm_add_dns_route_rule "$CONFIG" "fakeip-server" "fakeip-dns-rule-id")
#######################################
sing_box_cm_add_dns_route_rule() {
    local config="$1"
    local server="$2"
    local tag="$3"

    echo "$config" | jq \
        --arg server "$server" \
        --arg service_tag "$SERVICE_TAG" \
        --arg tag "$tag" \
        '.dns.rules += [{
            action: "route",
            server: $server,
            $service_tag: $tag
        }]'
}

#######################################
# Patch a DNS routing rule in the DNS section of a sing-box JSON configuration.
# Arguments:
#   config: string (JSON), sing-box configuration to modify
#   tag: string, identifier of the rule to patch
#   key: string, the key in the rule to update or add
#   value: string, JSON value to assign to the key
# Outputs:
#   Writes updated JSON configuration to stdout
# Example:
#   CONFIG=$(sing_box_cm_patch_dns_route_rule "$CONFIG" "fakeip-dns-rule-id" "rule_set" "main")
#   CONFIG=$(sing_box_cm_patch_dns_route_rule "$CONFIG" "fakeip-dns-rule-id" "rule_set" '["main","second"]')
#   CONFIG=$(sing_box_cm_patch_dns_route_rule "$CONFIG" "fakeip-dns-rule-id" "domain" "example.com")
#######################################
sing_box_cm_patch_dns_route_rule() {
    local config="$1"
    local tag="$2"
    local key="$3"
    local value="$4"

    value=$(_normalize_arg "$value")

    echo "$config" | jq \
        --arg service_tag "$SERVICE_TAG" \
        --arg tag "$tag" \
        --arg key "$key" \
        --argjson value "$value" \
        'import "helpers" as h {"search": "/usr/lib/netshift"};
        .dns.rules |= map(
            if .[$service_tag] == $tag then
                if has($key) then
                    .[$key] |= h::extend_key_value(.; $value)
                else
                    . + { ($key): $value }
                end
            else
                .
            end
        )'
}

#######################################
# Add a DNS reject rule to the DNS section of a sing-box JSON configuration.
# Arguments:
#   config: string (JSON), sing-box configuration to modify
#   key: string, the key to set for the reject rule
#   value: string, JSON value to assign to the key
# Outputs:
#   Writes updated JSON configuration to stdout
# Example:
#   CONFIG=$(sing_box_cm_add_dns_reject_rule "$CONFIG" "query_type" "HTTPS")
#######################################
sing_box_cm_add_dns_reject_rule() {
    local config="$1"
    local key="$2"
    local value="$3"

    value=$(_normalize_arg "$value")

    echo "$config" | jq \
        --arg key "$key" \
        --argjson value "$value" \
        '.dns.rules += [{
            action: "reject",
            ($key): $value
        }]'
}

#######################################
# Add a TProxy inbound to the inbounds section of a sing-box JSON configuration.
# Arguments:
#   config: string (JSON), sing-box configuration to modify
#   tag: string, identifier for the inbound
#   listen_address: string, IP address to listen on
#   listen_port: integer, port to listen on
#   tcp_fast_open: boolean, enable or disable TCP Fast Open
#   udp_fragment: boolean, enable or disable UDP fragmentation
# Outputs:
#   Writes updated JSON configuration to stdout
# Example:
#   CONFIG=$(sing_box_cm_add_tproxy_inbound "$CONFIG" "tproxy-in" "127.0.0.1" 6969 true true)
#######################################
sing_box_cm_add_tproxy_inbound() {
    local config="$1"
    local tag="$2"
    local listen_address="$3"
    local listen_port="$4"
    local tcp_fast_open="$5"
    local udp_fragment="$6"

    echo "$config" | jq \
        --arg tag "$tag" \
        --arg listen_address "$listen_address" \
        --argjson listen_port "$listen_port" \
        --argjson tcp_fast_open "$tcp_fast_open" \
        --argjson udp_fragment "$udp_fragment" \
        '.inbounds += [{
    		type: "tproxy",
			tag: $tag,
			listen: $listen_address,
    		listen_port: $listen_port,
    		tcp_fast_open: $tcp_fast_open,
    		udp_fragment: $udp_fragment
		}]'
}

#######################################
# Add a Direct inbound to the inbounds section of a sing-box JSON configuration.
# Arguments:
#   config: string (JSON), sing-box configuration to modify
#   tag: string, identifier for the inbound
#   listen_address: string, IP address to listen on
#   listen_port: integer, port to listen on
# Outputs:
#   Writes updated JSON configuration to stdout
# Example:
#   CONFIG=$(sing_box_cm_add_direct_inbound "$CONFIG" "dns-in" "127.0.0.42" 53)
#######################################
sing_box_cm_add_direct_inbound() {
    local config="$1"
    local tag="$2"
    local listen_address="$3"
    local listen_port="$4"

    echo "$config" | jq \
        --arg tag "$tag" \
        --arg listen_address "$listen_address" \
        --argjson listen_port "$listen_port" \
        '.inbounds += [{
			type: "direct",
			tag: $tag,
			listen: $listen_address,
			listen_port: $listen_port,
		}]'
}

#######################################
# Add a Mixed inbound to the inbounds section of a sing-box JSON configuration.
# Arguments:
#   config: string (JSON), sing-box configuration to modify
#   tag: string, identifier for the inbound
#   listen_address: string, IP address to listen on
#   listen_port: integer, port to listen on
#   username, password: strings, optional; with both set the inbound requires them
# Outputs:
#   Writes updated JSON configuration to stdout
# Example:
#   CONFIG=$(sing_box_cm_add_mixed_inbound "$CONFIG" "tproxy-in" "192.168.1.1" 2080)
#######################################
sing_box_cm_add_mixed_inbound() {
    local config="$1"
    local tag="$2"
    local listen_address="$3"
    local listen_port="$4"
    local username="${5:-}"
    local password="${6:-}"

    echo "$config" | jq \
        --arg tag "$tag" \
        --arg listen_address "$listen_address" \
        --argjson listen_port "$listen_port" \
        --arg username "$username" \
        --arg password "$password" \
        '.inbounds += [{
			type: "mixed",
			tag: $tag,
			listen: $listen_address,
			listen_port: $listen_port,
		} + (if $username != "" and $password != "" then {users: [{username: $username, password: $password}]} else {} end)]'
}

#######################################
# Add a Direct outbound to the outbounds section of a sing-box JSON configuration.
# Arguments:
#   config: string (JSON), sing-box configuration to modify
#   tag: string, identifier for the outbound
# Outputs:
#   Writes updated JSON configuration to stdout
# Example:
#   CONFIG=$(sing_box_cm_add_direct_outbound "$CONFIG" "direct-out")
#######################################
sing_box_cm_add_direct_outbound() {
    local config="$1"
    local tag="$2"

    echo "$config" | jq \
        --arg tag "$tag" \
        '.outbounds += [{
            type: "direct",
            tag: $tag
        }]'
}

#######################################
# Add a NaiveProxy outbound (sing-box 1.13+, built with the naive outbound).
# Arguments:
#   config: string (JSON), sing-box configuration to modify
#   tag, server, server_port, username, password
#   quic: "true" to carry the connection over QUIC (naive+quic links)
# Outputs:
#   Writes updated JSON configuration to stdout
#######################################
sing_box_cm_add_naive_outbound() {
    local config="$1"
    local tag="$2"
    local server="$3"
    local server_port="$4"
    local username="$5"
    local password="$6"
    local quic="$7"
    local server_is_ip=""

    # no jq regex on OpenWrt: the shell tells an address from a name
    if is_ipv4 "$server" || is_ipv6 "$server"; then
        server_is_ip="1"
    fi

    echo "$config" | jq \
        --arg tag "$tag" \
        --arg server "$server" \
        --arg server_is_ip "$server_is_ip" \
        --arg server_port "$server_port" \
        --arg username "$username" \
        --arg password "$password" \
        --arg quic "$quic" \
        '.outbounds += [(
            {
                type: "naive",
                tag: $tag,
                server: $server,
                server_port: ($server_port | tonumber),
                tls: ({enabled: true} + (if $server_is_ip == "1" then {} else {server_name: $server} end))
            }
            + (if $username != "" then {username: $username} else {} end)
            + (if $password != "" then {password: $password} else {} end)
            + (if $quic == "true" then {quic: true} else {} end)
        )]'
}

#######################################
# Add a SOCKS outbound to the outbounds section of a sing-box JSON configuration.
# Arguments:
#   config: string (JSON), sing-box configuration to modify
#   tag: string, identifier for the outbound
#   server_address: string, IP address or hostname of the SOCKS server
#   server_port: integer, port of the SOCKS server
#   version: string, SOCKS version (optional)
#   username: string, username for authentication (optional)
#   password: string, password for authentication (optional)
#   network: string, network type (e.g., "tcp") (optional)
#   udp_over_tcp: integer, version for UDP over TCP (optional)
# Outputs:
#   Writes updated JSON configuration to stdout
# Example:
#   CONFIG=$(sing_box_cm_add_socks_outbound "$CONFIG" "socks5-out" "192.168.1.10" 1080)
#######################################
sing_box_cm_add_socks_outbound() {
    local config="$1"
    local tag="$2"
    local server_address="$3"
    local server_port="$4"
    local version="$5"
    local username="$6"
    local password="$7"
    local network="$8"
    local udp_over_tcp="$9"

    echo "$config" | jq \
        --arg tag "$tag" \
        --arg server_address "$server_address" \
        --arg server_port "$server_port" \
        --arg version "$version" \
        --arg username "$username" \
        --arg password "$password" \
        --arg network "$network" \
        --arg udp_over_tcp "$udp_over_tcp" \
        '.outbounds += [(
            {
              type: "socks",
              tag: $tag,
              server: $server_address,
              server_port: ($server_port | tonumber)
            }
            + (if $version != "" then {version: $version} else {} end)
            + (if $username != "" then {username: $username} else {} end)
            + (if $password != "" then {password: $password} else {} end)
            + (if $network != "" then {network: $network} else {} end)
            + (if $udp_over_tcp != "" then {
                udp_over_tcp: {
                    enabled: true,
                    version: ($udp_over_tcp | tonumber)
                }
            } else {} end)

        )]'
}

#######################################
# Add a Shadowsocks outbound to the outbounds section of a sing-box JSON configuration.
# Arguments:
#   config: string (JSON), sing-box configuration to modify
#   tag: string, identifier for the outbound
#   server_address: string, IP address or hostname of the Shadowsocks server
#   server_port: integer, port of the Shadowsocks server
#   method: string, encryption method
#   password: string, password for encryption
#   network: string, network type (e.g., "tcp") (optional)
#   udp_over_tcp: integer, version for UDP over TCP (optional)
#   plugin: string, plugin name (optional)
#   plugin_opts: string, plugin options (optional)
# Outputs:
#   Writes updated JSON configuration to stdout
# Example:
#   CONFIG=$(
#       sing_box_cm_add_shadowsocks_outbound "$CONFIG" "ss-out" "127.0.0.1" 443 \
#       "2022-blake3-aes-128-gcm" "8JCsPssfgS8tiRwiMlhARg=="
#   )
#######################################
sing_box_cm_add_shadowsocks_outbound() {
    local config="$1"
    local tag="$2"
    local server_address="$3"
    local server_port="$4"
    local method="$5"
    local password="$6"
    local network="$7"
    local udp_over_tcp="$8"
    local plugin="$9"
    local plugin_opts="${10}"

    echo "$config" | jq \
        --arg tag "$tag" \
        --arg server_address "$server_address" \
        --arg server_port "$server_port" \
        --arg method "$method" \
        --arg password "$password" \
        --arg plugin "$plugin" \
        --arg plugin_opts "$plugin_opts" \
        --arg network "$network" \
        --arg udp_over_tcp "$udp_over_tcp" \
        '.outbounds += [(
            {
              type: "shadowsocks",
              tag: $tag,
              server: $server_address,
              server_port: ($server_port | tonumber),
              method: $method,
              password: $password
            }
            + (if $plugin != "" then {plugin: $plugin} else {} end)
            + (if $plugin_opts != "" then {plugin_opts: $plugin_opts} else {} end)
            + (if $network != "" then {network: $network} else {} end)
            + (if $udp_over_tcp != "" then {
                udp_over_tcp: {
                    enabled: true,
                    version: ($udp_over_tcp | tonumber)
                }
            } else {} end)
        )]'
}

#######################################
# Add a VLESS outbound to the outbounds section of a sing-box JSON configuration.
# Arguments:
#   config: string (JSON), sing-box configuration to modify
#   tag: string, identifier for the outbound
#   server_address: string, IP address or hostname of the VLESS server
#   server_port: integer, port of the VLESS server
#   uuid: string, user UUID
#   flow: string, flow setting (optional)
#   network: string, network type (e.g., "tcp") (optional)
#   packet_encoding: string, packet encoding method (optional)
#   encryption: string, VLESS Encryption handshake (optional; the
#       mlkem768x25519plus... value from the link's encryption= param).
#       "none" and empty are omitted so configs for ordinary VLESS
#       links stay byte-for-byte what they were.
# Outputs:
#   Writes updated JSON configuration to stdout
# Example:
#   CONFIG=$(
#       sing_box_cm_add_vless_outbound "$CONFIG" "vless-reality-out" "example.com" 443 \
#       "bf000d23-0752-40b4-affe-68f7707a9661" "xtls-rprx-vision"
#   )
#######################################
sing_box_cm_add_vless_outbound() {
    local config="$1"
    local tag="$2"
    local server_address="$3"
    local server_port="$4"
    local uuid="$5"
    local flow="$6"
    local network="$7"
    local packet_encoding="$8"
    local encryption="$9"

    echo "$config" | jq \
        --arg tag "$tag" \
        --arg server_address "$server_address" \
        --arg server_port "$server_port" \
        --arg uuid "$uuid" \
        --arg flow "$flow" \
        --arg network "$network" \
        --arg packet_encoding "$packet_encoding" \
        --arg encryption "$encryption" \
        '.outbounds += [(
            {
              type: "vless",
              tag: $tag,
              server: $server_address,
              server_port: ($server_port | tonumber),
              uuid: $uuid
            }
            + (if $flow != "" then {flow: $flow} else {} end)
            + (if $network != "" then {network: $network} else {} end)
            + (if $packet_encoding != "" then {packet_encoding: $packet_encoding} else {} end)
            + (if $encryption != "" and $encryption != "none"
               then {encryption: $encryption} else {} end)
        )]'
}

#######################################
# Add a VMess outbound to the outbounds section of a sing-box JSON configuration.
# Requires sing-box-extended on the router (gated by the facade).
# Arguments:
#   config: string (JSON), sing-box configuration to modify
#   tag: string, identifier for the outbound
#   server_address: string, IP address or hostname of the VMess server
#   server_port: integer, port of the VMess server
#   uuid: string, user UUID
#   security: string, encryption method (optional; defaults to "auto" when empty)
#   alter_id: integer, alterId (optional; omitted when empty or 0)
# Outputs:
#   Writes updated JSON configuration to stdout
# Example:
#   CONFIG=$(
#       sing_box_cm_add_vmess_outbound "$CONFIG" "vmess-out" "example.com" 443 \
#       "bf000d23-0752-40b4-affe-68f7707a9661" "auto" "0"
#   )
#######################################
sing_box_cm_add_vmess_outbound() {
    local config="$1"
    local tag="$2"
    local server_address="$3"
    local server_port="$4"
    local uuid="$5"
    local security="$6"
    local alter_id="$7"

    [ -n "$security" ] || security="auto"

    echo "$config" | jq \
        --arg tag "$tag" \
        --arg server_address "$server_address" \
        --arg server_port "$server_port" \
        --arg uuid "$uuid" \
        --arg security "$security" \
        --arg alter_id "$alter_id" \
        '.outbounds += [(
            {
              type: "vmess",
              tag: $tag,
              server: $server_address,
              server_port: ($server_port | tonumber),
              uuid: $uuid,
              security: $security
            }
            + (if $alter_id != "" and $alter_id != "0" then {alter_id: ($alter_id | tonumber)} else {} end)
        )]'
}

#######################################
# Add a Trojan outbound to the outbounds section of a sing-box JSON configuration.
# Arguments:
#   config: string (JSON), sing-box configuration to modify
#   tag: string, identifier for the outbound
#   server_address: string, IP address or hostname of the Trojan server
#   server_port: integer, port of the Trojan server
#   password: string, password for authentication
#   network: string, network type (e.g., "tcp") (optional)
# Outputs:
#   Writes updated JSON configuration to stdout
# Example:
#   CONFIG=$(sing_box_cm_add_trojan_outbound "$CONFIG" "trojan-out" "example.com" 443 "supersecretpassword" "tcp")
#######################################
sing_box_cm_add_trojan_outbound() {
    local config="$1"
    local tag="$2"
    local server_address="$3"
    local server_port="$4"
    local password="$5"
    local network="$6"

    echo "$config" | jq \
        --arg tag "$tag" \
        --arg server_address "$server_address" \
        --arg server_port "$server_port" \
        --arg password "$password" \
        --arg network "$network" \
        '.outbounds += [(
        {
          type: "trojan",
          tag: $tag,
          server: $server_address,
          server_port: ($server_port | tonumber),
          password: $password
        }
        + (if $network != "" then {network: $network} else {} end)
    )]'
}

#######################################
# Add a TUIC outbound (needs QUIC in the core; the TLS block comes separately).
# Arguments:
#   config, tag, server, server_port, uuid, password
#   congestion_control: bbr, cubic or new_reno (optional)
#   udp_relay_mode: native or quic (optional)
# Outputs:
#   Updated JSON config to stdout
#######################################
sing_box_cm_add_tuic_outbound() {
    local config="$1"
    local tag="$2"
    local server="$3"
    local server_port="$4"
    local uuid="$5"
    local password="$6"
    local congestion_control="$7"
    local udp_relay_mode="$8"

    echo "$config" | jq \
        --arg tag "$tag" \
        --arg server "$server" \
        --arg server_port "$server_port" \
        --arg uuid "$uuid" \
        --arg password "$password" \
        --arg congestion_control "$congestion_control" \
        --arg udp_relay_mode "$udp_relay_mode" \
        '.outbounds += [(
            {
                type: "tuic",
                tag: $tag,
                server: $server,
                server_port: ($server_port | tonumber),
                uuid: $uuid
            }
            + (if $password != "" then {password: $password} else {} end)
            + (if $congestion_control != "" then {congestion_control: $congestion_control} else {} end)
            + (if $udp_relay_mode != "" then {udp_relay_mode: $udp_relay_mode} else {} end)
        )]'
}

#######################################
# Add an AnyTLS outbound (sing-box 1.12+; the TLS block comes separately).
# Arguments:
#   config, tag, server, server_port, password
# Outputs:
#   Updated JSON config to stdout
#######################################
sing_box_cm_add_anytls_outbound() {
    local config="$1"
    local tag="$2"
    local server="$3"
    local server_port="$4"
    local password="$5"

    echo "$config" | jq \
        --arg tag "$tag" \
        --arg server "$server" \
        --arg server_port "$server_port" \
        --arg password "$password" \
        '.outbounds += [{
            type: "anytls",
            tag: $tag,
            server: $server,
            server_port: ($server_port | tonumber),
            password: $password
        }]'
}

#######################################
# Add a Hysteria2 outbound to the outbounds section of a sing-box JSON configuration.
# Arguments:
#   config: string (JSON), sing-box configuration to modify
#   tag: string, identifier for the outbound
#   server_address: string, IP address or hostname of the Hysteria2 server
#   server_port: integer, port of the Hysteria2 server
#   password: string, password for authentication
#   obfuscator_type: string, obfuscation type (optional)
#   obfuscator_password: string, obfuscation password (optional)
#   upload_mbps: integer, upload bandwidth limit in Mbps (optional)
#   download_mbps: integer, download bandwidth limit in Mbps (optional)
#   network: string, network type (e.g., "udp") (optional)
#   hop_interval: string, port hopping interval, e.g. "30s" (optional, only with several ports)
# Outputs:
#   Writes updated JSON configuration to stdout
# Example:
#   CONFIG=$(sing_box_cm_add_hysteria2_outbound "$CONFIG" "hysteria2-out" "example.com" 443 "supersecret" \
#       "salamander" "obfs-pass" "50" "200" "udp")
#######################################
sing_box_cm_add_hysteria2_outbound() {
    local config="$1"
    local tag="$2"
    local server_address="$3"
    local server_port="$4"
    local password="$5"
    local obfuscator_type="$6"
    local obfuscator_password="$7"
    local upload_mbps="$8"
    local download_mbps="$9"
    local network="${10}"
    local hop_interval="${11:-}"

    local is_multi_port="false"
    case "$server_port" in
        *","*|*"-"*) is_multi_port="true" ;;
    esac

    echo "$config" | jq \
        --arg tag "$tag" \
        --arg server_address "$server_address" \
        --arg server_port "$server_port" \
        --arg password "$password" \
        --arg obfuscator_type "$obfuscator_type" \
        --arg obfuscator_password "$obfuscator_password" \
        --arg upload_mbps "$upload_mbps" \
        --arg download_mbps "$download_mbps" \
        --arg network "$network" \
        --arg hop_interval "$hop_interval" \
        --argjson is_multi_port "$is_multi_port" \
        '
        def parse_port_entry:
            if index("-") then split("-") | join(":")
            else . + ":" + .
            end;

        .outbounds += [(
        {
          type: "hysteria2",
          tag: $tag,
          server: $server_address,
          password: $password
        }
        + (if $is_multi_port then {
                server_ports: ($server_port | split(",") | map(ltrimstr(" ") | rtrimstr(" ") | parse_port_entry))
            }
            + (if $hop_interval != "" then {hop_interval: $hop_interval} else {} end)
            else {
                server_port: ($server_port | tonumber)
            } end)
        + (if $obfuscator_type != "" and $obfuscator_password != "" then {
            obfs: {
                type: $obfuscator_type,
                password: $obfuscator_password
            }
        } else {} end)
        + (if $upload_mbps != "" then {up_mbps: ($upload_mbps | tonumber)} else {} end)
        + (if $download_mbps != "" then {down_mbps: ($download_mbps | tonumber)} else {} end)
        + (if $network != "" then {network: $network} else {} end)
    )]'
}

#######################################
# Set gRPC transport settings for an outbound in a sing-box JSON configuration.
# Arguments:
#   config: string (JSON), sing-box configuration to modify
#   tag: string, identifier of the outbound to modify
#   service_name: string, gRPC service name (optional)
#   idle_timeout: string or integer, idle timeout (optional)
#   ping_timeout: string or integer, ping timeout (optional)
#   permit_without_stream: boolean, flag for permitting without stream (optional)
# Outputs:
#   Writes updated JSON configuration to stdout
# Example:
#   CONFIG=$(sing_box_cm_set_grpc_transport_for_outbound "$CONFIG" "vless-tls-grpc-out")
#######################################
sing_box_cm_set_grpc_transport_for_outbound() {
    local config="$1"
    local tag="$2"
    local service_name="$3"
    local idle_timeout="$4"
    local ping_timeout="$5"
    local permit_without_stream="$6"

    echo "$config" | jq \
        --arg tag "$tag" \
        --arg service_name "$service_name" \
        --arg idle_timeout "$idle_timeout" \
        --arg ping_timeout "$ping_timeout" \
        --arg permit_without_stream "$permit_without_stream" \
        '.outbounds |= map(
            if .tag == $tag then
                . + {
                    transport: (
                        { type: "grpc" }
                        + (if $service_name != "" then {service_name: $service_name} else {} end)
                        + (if $idle_timeout != "" then {idle_timeout: $idle_timeout} else {} end)
                        + (if $ping_timeout != "" then {ping_timeout: $ping_timeout} else {} end)
                        + (if $permit_without_stream != "" then {permit_without_stream: $permit_without_stream} else {} end)
                    )
                }
            else
                .
            end
        )'
}

#######################################
# Set WebSocket transport settings for an outbound in a sing-box JSON configuration.
# Arguments:
#   config: string (JSON), sing-box configuration to modify
#   tag: string, identifier of the outbound to modify
#   path: string, WebSocket path
#   host: string, Host header for WebSocket (optional)
#   max_early_data: integer, maximum early data (optional)
#   early_data_header_name: string, header name for early data (optional)
# Outputs:
#   Writes updated JSON configuration to stdout
# Example:
#   CONFIG=$(sing_box_cm_set_ws_transport_for_outbound "$CONFIG" "vless-tls-ws-out" "/path" "example.com")
#######################################
sing_box_cm_set_ws_transport_for_outbound() {
    local config="$1"
    local tag="$2"
    local path="$3"
    local host="$4"
    local max_early_data="$5"
    local early_data_header_name="$6"

    # Not sure if the "Host" parameter in headers is correct — needs verification
    echo "$config" | jq \
        --arg tag "$tag" \
        --arg path "$path" \
        --arg host "$host" \
        --arg max_early_data "$max_early_data" \
        --arg early_data_header_name "$early_data_header_name" \
        '.outbounds |= map(
            if .tag == $tag then
                . + {
                    transport: (
                        {
                            type: "ws",
                            path: $path
                        }
                        + (if $host != "" then {headers: {Host: $host}} else {} end)
                        + (if $max_early_data != "" then {max_early_data: $max_early_data | tonumber} else {} end)
                        + (if $early_data_header_name != "" then
                            {early_data_header_name: $early_data_header_name}
                        else {} end)
                    )
                }
            else
                .
            end
        )'
}

#######################################
# Set HTTPUpgrade transport settings for an outbound in a sing-box JSON
# configuration. sing-box's httpupgrade transport is an upstream feature
# (shipped since 1.8), so no extended core is required. The Host header lives in
# a top-level "host" field (unlike ws, which nests it under headers.Host); when
# host is empty the caller passes the sni instead, matching the common
# TLS-fronted deployment where the Host equals the TLS SNI.
# Arguments:
#   config: string (JSON), sing-box configuration to modify
#   tag: string, identifier of the outbound to modify
#   path: string, HTTPUpgrade path (defaults to "/" if empty)
#   host: string, Host header (optional)
# Outputs:
#   Writes updated JSON configuration to stdout
# Example:
#   CONFIG=$(sing_box_cm_set_httpupgrade_transport_for_outbound "$CONFIG" "vless-hu-out" "/path" "example.com")
#######################################
sing_box_cm_set_httpupgrade_transport_for_outbound() {
    local config="$1"
    local tag="$2"
    local path="$3"
    local host="$4"

    [ -n "$path" ] || path="/"

    echo "$config" | jq \
        --arg tag "$tag" \
        --arg path "$path" \
        --arg host "$host" \
        '.outbounds |= map(
            if .tag == $tag then
                . + {
                    transport: (
                        {
                            type: "httpupgrade",
                            path: $path
                        }
                        + (if $host != "" then {host: $host} else {} end)
                    )
                }
            else
                .
            end
        )'
}

#######################################
# Set HTTP/2 transport settings for an outbound in a sing-box JSON configuration.
# Used for VMess net=h2 links (sing-box "http" transport). HTTP/2 transport
# mandates TLS, so the caller must also set TLS on the outbound.
# Arguments:
#   config: string (JSON), sing-box configuration to modify
#   tag: string, identifier of the outbound to modify
#   path: string, HTTP path (optional)
#   host: string, Host header (single host; optional)
# Outputs:
#   Writes updated JSON configuration to stdout
# Example:
#   CONFIG=$(sing_box_cm_set_http_transport_for_outbound "$CONFIG" "vmess-out" "/path" "example.com")
#######################################
sing_box_cm_set_http_transport_for_outbound() {
    local config="$1"
    local tag="$2"
    local path="$3"
    local host="$4"

    echo "$config" | jq \
        --arg tag "$tag" \
        --arg path "$path" \
        --arg host "$host" \
        '.outbounds |= map(
            if .tag == $tag then
                . + {
                    transport: (
                        { type: "http" }
                        + (if $path != "" then {path: $path} else {} end)
                        + (if $host != "" then {host: [$host]} else {} end)
                    )
                }
            else
                .
            end
        )'
}

#######################################
# Set XHTTP transport settings for an outbound in a sing-box JSON configuration.
# Requires sing-box-extended on the router.
# Arguments:
#   config: string (JSON), sing-box configuration to modify
#   tag: string, identifier of the outbound to modify
#   path: string, XHTTP path (defaults to "/" if empty)
#   host: string, Host header for XHTTP (optional)
#   mode: string, XHTTP mode (auto|packet-up|stream-up|stream-one; defaults to "auto")
#   extra: string (JSON object), already-sanitized transport options from
#          sing_box_cm_xhttp_extra_options (optional, defaults to {}); they replace the defaults
# Outputs:
#   Writes updated JSON configuration to stdout
# Example:
#   CONFIG=$(sing_box_cm_set_xhttp_transport_for_outbound "$CONFIG" "vless-xhttp-out" "/path" "example.com" "auto")
#######################################
sing_box_cm_set_xhttp_transport_for_outbound() {
    local config="$1"
    local tag="$2"
    local path="$3"
    local host="$4"
    local mode="$5"
    local extra="${6:-}"

    case "$mode" in
    auto | packet-up | stream-up | stream-one) ;;
    *) mode="auto" ;;
    esac

    [ -n "$path" ] || path="/"
    [ -n "$extra" ] || extra="{}"

    echo "$config" | jq \
        --arg tag "$tag" \
        --arg path "$path" \
        --arg host "$host" \
        --arg mode "$mode" \
        --argjson extra "$extra" \
        '.outbounds |= map(
            if .tag == $tag then
                . + {
                    transport: (
                        {
                            type: "xhttp",
                            mode: $mode,
                            path: $path,
                            x_padding_bytes: "100-1000",
                            no_grpc_header: false,
                            sc_max_each_post_bytes: 1000000,
                            sc_min_posts_interval_ms: 30
                        }
                        + (if $host != "" then {host: $host} else {} end)
                        + $extra
                    )
                }
            else
                .
            end
        )'
}

#######################################
# The `extra` of an XHTTP share link (Xray's xhttpSettings.extra: padding, post sizes and intervals,
# xmux, placements ...) as options of the sing-box-extended xhttp transport. Only known keys with
# usable values pass: the core refuses a whole configuration for one bad value, so a value that
# is out of range, has a wrong type or is not in the allowed set is dropped, and the transport
# keeps its default for it. Ranges are a number or "from-to" (digits only, no regex).
# Arguments:
#   extra: string, the decoded JSON of the link's `extra` parameter (may be empty)
#   mode: string, XHTTP mode of the link (some values are valid only in packet-up)
#   padding: string, the link's own x_padding_bytes parameter (3x-ui writes it next to `extra`),
#            used when `extra` does not carry xPaddingBytes (optional)
# Outputs:
#   A JSON object of transport options on stdout; "{}" when there is nothing usable
#######################################
sing_box_cm_xhttp_extra_options() {
    local extra="${1:-}"
    local mode="${2:-auto}"
    local padding="${3:-}"

    [ -n "$extra" ] || extra="null"
    if ! printf '%s' "$extra" | jq -e 'type == "object"' > /dev/null 2>&1; then
        extra="null"
    fi

    printf '%s' "$extra" | jq -c --arg mode "$mode" --arg padding "$padding" '
        def digits: type == "string" and length > 0 and length <= 9 and all(explode[]; . >= 48 and . <= 57);
        def rng($min):
            if type == "number" then
                (if . == floor and . >= $min and . <= 2147483647 then . else null end)
            elif type == "string" then
                (split("-")) as $p
                | if ($p | length) == 1 and ($p[0] | digits) then
                    (($p[0] | tonumber) as $n | if $n >= $min then $n else null end)
                  elif ($p | length) == 2 and ($p[0] | digits) and ($p[1] | digits) then
                    (($p[0] | tonumber) as $a | ($p[1] | tonumber) as $b
                     | if $a >= $min and $b >= $a then "\($a)-\($b)" else null end)
                  else null end
            else null end;
        def rng_to: if type == "number" then . else (split("-") | last | tonumber) end;
        def uint: if type == "number" and . == floor and . >= 0 and . <= 2147483647 then . else null end;
        def bool: if type == "boolean" then . else null end;
        def enum($list): if type == "string" and (. as $v | $list | index($v)) != null then . else null end;
        def key:
            if type == "string" and length >= 1 and length <= 64
               and all(explode[]; (. >= 48 and . <= 57) or (. >= 65 and . <= 90) or (. >= 97 and . <= 122) or . == 45 or . == 95)
            then . else null end;
        def packet_up: $mode == "packet-up";

        (if type == "object" then . else {} end) as $e
        | ($e.xmux | if type == "object" then . else {} end) as $x
        | ({
            max_concurrency: ($x.maxConcurrency | rng(0)),
            max_connections: ($x.maxConnections | rng(0)),
            c_max_reuse_times: ($x.cMaxReuseTimes | rng(0)),
            h_max_request_times: ($x.hMaxRequestTimes | rng(0)),
            h_max_reusable_secs: ($x.hMaxReusableSecs | rng(0)),
            h_keep_alive_period: ($x.hKeepAlivePeriod | uint)
          } | with_entries(select(.value != null))
            # the core refuses both of these set together: the link keeps max_concurrency
            | if (.max_connections // 0 | rng_to) > 0 and (.max_concurrency // 0 | rng_to) > 0 then del(.max_connections) else . end
          ) as $xmux
        | ($e.headers | if type == "object" then
              with_entries(select((.value | type) == "string" and ((.key | ascii_downcase) != "host")))
              | if length > 0 then . else null end
          else null end) as $headers
        | ({
            x_padding_bytes: (($e.xPaddingBytes | rng(1)) // ($padding | rng(1))),
            no_grpc_header: ($e.noGRPCHeader | bool),
            no_sse_header: ($e.noSSEHeader | bool),
            sc_max_each_post_bytes: ($e.scMaxEachPostBytes | rng(1)),
            sc_min_posts_interval_ms: ($e.scMinPostsIntervalMs | rng(0)),
            sc_max_buffered_posts: ($e.scMaxBufferedPosts | uint),
            sc_stream_up_server_secs: ($e.scStreamUpServerSecs | rng(0)),
            uplink_chunk_size: ($e.uplinkChunkSize | rng(0)),
            x_padding_obfs_mode: ($e.xPaddingObfsMode | bool),
            x_padding_key: ($e.xPaddingKey | key),
            x_padding_header: ($e.xPaddingHeader | key),
            x_padding_placement: ($e.xPaddingPlacement | enum(["cookie", "header", "query", "queryInHeader"])),
            x_padding_method: ($e.xPaddingMethod | enum(["repeat-x", "tokenish"])),
            uplink_http_method: ($e.uplinkHTTPMethod | if type == "string" then ascii_upcase else null end
                                 | enum(if packet_up then ["POST", "PUT", "GET"] else ["POST", "PUT"] end)),
            session_placement: ($e.sessionPlacement | enum(["path", "cookie", "header", "query"])),
            session_key: ($e.sessionKey | key),
            seq_placement: ($e.seqPlacement | enum(["path", "cookie", "header", "query"])),
            seq_key: ($e.seqKey | key),
            uplink_data_placement: ($e.uplinkDataPlacement | enum(if packet_up then ["auto", "body", "cookie", "header"] else ["auto", "body"] end)),
            uplink_data_key: ($e.uplinkDataKey | key),
            headers: $headers,
            xmux: (if ($xmux | length) > 0 then $xmux else null end)
          } | with_entries(select(.value != null)))' 2> /dev/null || echo '{}'
}

# The keys of an XHTTP `extra` that the transport does not take (printed comma-separated), so the
# log can say what was left out.
sing_box_cm_xhttp_extra_ignored() {
    printf '%s' "${1:-null}" | jq -r '
        ["xPaddingBytes", "noGRPCHeader", "noSSEHeader", "scMaxEachPostBytes", "scMinPostsIntervalMs", "scMaxBufferedPosts",
         "scStreamUpServerSecs", "uplinkChunkSize", "xPaddingObfsMode", "xPaddingKey", "xPaddingHeader", "xPaddingPlacement",
         "xPaddingMethod", "uplinkHTTPMethod", "sessionPlacement", "sessionKey", "seqPlacement", "seqKey",
         "uplinkDataPlacement", "uplinkDataKey", "headers", "xmux"] as $known
        | if type == "object" then (keys - $known | join(", ")) else "" end' 2> /dev/null
}

#######################################
# Set TLS settings for an outbound in a sing-box JSON configuration.
# Arguments:
#   config: string (JSON), sing-box configuration to modify
#   tag: string, identifier of the outbound to modify
#   server_name: string, used to verify the hostname on the returned certificates (optional)
#   insecure: boolean, accept any server certificate (optional)
#   alpn: string, JSON value, supported application level protocols (optional)
#   utls_fingerprint: string, uTLS fingerprint (optional)
#   reality_public_key: string, Reality public key (optional)
#   reality_short_id: string, Reality short ID (optional)
#   reality_mlkem: string, "true"/"false" writes `support_x25519mlkem768` into the Reality
#       block (sing-box-extended only; the caller gates it on the core) (optional)
# Outputs:
#   Writes updated JSON configuration to stdout
# Example:
#   CONFIG=$(
#       sing_box_cm_set_tls_for_outbound "$CONFIG" "vless-reality-out" "example.com" false null "chrome" \
#       "jNXHt1yRo0vDuchQlIP6Z0ZvjT3KtzVI-T4E7RoLJS0" "0123456789abcdef"
#   )
#######################################
sing_box_cm_set_tls_for_outbound() {
    local config="$1"
    local tag="$2"
    local server_name="$3"
    local insecure="$4"
    local alpn="$5"
    local utls_fingerprint="$6"
    local reality_public_key="$7"
    local reality_short_id="$8"
    local reality_mlkem="${9:-}"

    echo "$config" | jq \
        --arg tag "$tag" \
        --arg reality_mlkem "$reality_mlkem" \
        --arg server_name "$server_name" \
        --arg insecure "$insecure" \
        --argjson alpn "$alpn" \
        --arg utls_fingerprint "$utls_fingerprint" \
        --arg reality_public_key "$reality_public_key" \
        --arg reality_short_id "$reality_short_id" \
        '.outbounds |= map(
            if .tag == $tag then
                . + {
                    tls: (
                        { enabled: true }
                        + (if $server_name != "" then {server_name: $server_name} else {} end)
                        + (if $insecure == "true" then {insecure: true} else {} end)
                        + (if $alpn != null then {alpn: $alpn} else {} end)
                        + (if $utls_fingerprint != "" then {
                            utls: {
                                enabled: true,
                                fingerprint: $utls_fingerprint
                            }
                        } else {} end)
                        + (if $reality_public_key != "" then {
                            reality: {
                                enabled: true,
                                public_key: $reality_public_key,
                                short_id: $reality_short_id
                            }
                            + (if $reality_mlkem == "true" then {support_x25519mlkem768: true}
                               elif $reality_mlkem == "false" then {support_x25519mlkem768: false}
                               else {} end)
                        } else {} end)
                    )
                }
            else
                .
            end
        )'
}

#######################################
# Resolve proxy server addresses independently when the main DNS uses a proxy.
# Otherwise the proxy inherits route.default_domain_resolver and resolving its
# own hostname tries to open the same proxy again (DNS resolution loop).
# Keep explicit resolvers and chained outbounds intact. The resolver has no
# effect for a numeric server address; direct and group outbounds have no server.
# Arguments: config (JSON), bootstrap DNS tag, main DNS detour tag (empty = off).
#######################################
sing_box_cm_set_proxy_bootstrap_resolver() {
    local config="$1"
    local bootstrap_resolver="$2"
    local dns_detour="$3"

    if [ -z "$dns_detour" ]; then
        printf '%s\n' "$config"
        return 0
    fi

    printf '%s' "$config" | jq --arg resolver "$bootstrap_resolver" '
        .outbounds |= map(
            if ((.server | type) == "string") and (.server != "")
                and ((.domain_resolver // "") == "")
                and ((.detour // "") == "") then
                . + {domain_resolver: $resolver}
            else . end
        )'
}

#######################################
# Add a Direct outbound with a specific network interface to a sing-box JSON configuration.
# Arguments:
#   config: string (JSON), sing-box configuration to modify
#   tag: string, identifier for the outbound
#   interface: string, network interface to bind the outbound
#   domain_resolver: string, tag of the domain resolver to be used for this outbound (optional)
# Outputs:
#   Writes updated JSON configuration to stdout
# Example:
#   CONFIG=$(sing_box_cm_add_interface_outbound "$CONFIG" "warp-out" "awg0")
#######################################
sing_box_cm_add_interface_outbound() {
    local config="$1"
    local tag="$2"
    local interface="$3"
    local domain_resolver="$4"

    echo "$config" | jq \
        --arg tag "$tag" \
        --arg interface "$interface" \
        --arg domain_resolver "$domain_resolver" \
        '.outbounds += [
            {
                type: "direct",
                tag: $tag,
                bind_interface: $interface
            }
            + (if $domain_resolver != "" then {domain_resolver: $domain_resolver} else {} end)
        ]'
}

#######################################
# Add a raw outbound JSON object to the outbounds section of a sing-box configuration.
# Arguments:
#   config: string (JSON), sing-box configuration to modify
#   tag: string, identifier for the outbound
#   raw_outbound: string, JSON object, the raw outbound configuration to add
# Outputs:
#   Writes updated JSON configuration to stdout
# Example:
#   CONFIG=$(sing_box_cm_add_raw_outbound "$CONFIG" "raw-out" '{"type":"trojan","tag":"trojan-out","server":"127.0.0.1","server_port":1080,"password":"8JCsPssfgS8tiRwiMlhARg==","network":"tcp"}')
#######################################
sing_box_cm_add_raw_outbound() {
    local config="$1"
    local tag="$2"
    local raw_outbound="$3"

    echo "$config" | jq \
        --arg tag "$tag" \
        --argjson raw_outbound "$raw_outbound" \
        '.outbounds += [(
            $raw_outbound + {tag: $tag}
        )]'
}

#######################################
# Add a URLTest outbound to the outbounds section of a sing-box JSON configuration.
# Arguments:
#   config: string (JSON), sing-box configuration to modify
#   tag: string, identifier for the URLTest outbound
#   outbounds: string, JSON array of outbound tags to test
#   url: string, URL to probe (optional)
#   interval: string, test interval (e.g., "10s", or "off" for a single test at start) (optional)
#   tolerance: string or integer, max latency difference tolerated (optional)
#   idle_timeout: string or integer, idle timeout duration (optional)
#   interrupt_exist_connections: boolean, flag to interrupt existing connections ("true"/"false") (optional)
# Outputs:
#   Writes updated JSON configuration to stdout
# Example:
#   CONFIG=$(sing_box_cm_add_urltest_outbound "$CONFIG" "auto-select" '["proxy1","proxy2"]')
#######################################
sing_box_cm_add_urltest_outbound() {
    local config="$1"
    local tag="$2"
    local outbounds="$3"
    local url="$4"
    local interval="$5"
    local tolerance="$6"
    local idle_timeout="$7"
    local interrupt_exist_connections="$8"

    # "off": test once at start and not again (the core has no switch for it, a
    # year is as good as never).
    [ "$interval" != "off" ] || interval="${URLTEST_INTERVAL_OFF:-8760h}"

    # sing-box refuses to start an urltest whose interval is longer than its
    # idle_timeout ("interval must be less or equal than idle_timeout") and only
    # reports that at start, not in `sing-box check`. idle_timeout defaults to
    # 30m, so the longer intervals (1h, 6h, 24h) and "off" (a year) must raise it
    # or the whole service fails to start. Shorter intervals keep the default.
    if [ -z "$idle_timeout" ] && [ -n "$interval" ]; then
        local interval_seconds
        interval_seconds="$(_duration_to_seconds "$interval" 2> /dev/null)"
        # An interval this parser cannot read (a hand-written "1h30m") raises
        # idle_timeout as well: an interval longer than idle_timeout stops the
        # whole service, while idle_timeout equal to the interval is always
        # accepted.
        if [ -z "$interval_seconds" ] || [ "$interval_seconds" -gt "${URLTEST_IDLE_TIMEOUT_DEFAULT_SECONDS:-1800}" ]; then
            idle_timeout="$interval"
        fi
    fi

    echo "$config" | jq \
        --arg tag "$tag" \
        --argjson outbounds "$outbounds" \
        --arg url "$url" \
        --arg interval "$interval" \
        --arg tolerance "$tolerance" \
        --arg idle_timeout "$idle_timeout" \
        --arg interrupt_exist_connections "$interrupt_exist_connections" \
        '.outbounds += [
            {
                type: "urltest",
                tag: $tag,
                outbounds: $outbounds
            }
            + (if $url != "" then {url: $url} else {} end)
            + (if $interval != "" then {interval: $interval} else {} end)
            + (if $tolerance != "" then {tolerance: ($tolerance | tonumber)} else {} end)
            + (if $idle_timeout != "" then {idle_timeout: $idle_timeout} else {} end)
            + (if $interrupt_exist_connections == "true" then {interrupt_exist_connections: true} else {} end)
        ]'
}

#######################################
# Add a Selector outbound to the outbounds section of a sing-box JSON configuration.
# Arguments:
#   config: string (JSON), sing-box configuration to modify
#   tag: string, identifier for the Selector outbound
#   outbounds: string (JSON), array of outbound tags to choose from
#   default: string, default outbound tag if none selected
#   interrupt_exist_connections: boolean, flag to interrupt existing connections ("true"/"false") (optional)
# Outputs:
#   Writes updated JSON configuration to stdout
# Example:
#   CONFIG=$(sing_box_cm_add_selector_outbound "$CONFIG" "select-proxy" '["proxy1","proxy2"]')
#######################################
sing_box_cm_add_selector_outbound() {
    local config="$1"
    local tag="$2"
    local outbounds="$3"
    local default="$4"
    local interrupt_exist_connections="$5"

    echo "$config" | jq \
        --arg tag "$tag" \
        --argjson outbounds "$outbounds" \
        --arg default "$default" \
        --arg interrupt_exist_connections "$interrupt_exist_connections" \
        '.outbounds += [
            {
                type: "selector",
                tag: $tag,
                outbounds: $outbounds,
                default: $default
            }
            + (if $interrupt_exist_connections == "true" then {interrupt_exist_connections: true} else {} end)
        ]'
}

#######################################
# Configure the route section of a sing-box JSON configuration.
# Arguments:
#   config: string (JSON), sing-box configuration to modify
#   final: string, final outbound tag for unmatched traffic
#   auto_detect_interface: boolean, enable or disable automatic interface detection
#   default_domain_resolver: string, default DNS resolver for domain-based routing
#   default_interface: string, default network interface to use when auto detection is disabled (optional)
#   default_mark: integer, routing mark stamped on sing-box's own egress
#       connections so the nft/ip-rule tproxy path does not re-capture them
#       (optional; empty -> omitted, byte-identical to the no-mark output)
# Outputs:
#   Writes updated JSON configuration to stdout
# Example:
#   CONFIG=$(sing_box_cm_configure_route "$CONFIG" "direct-out" true "udp-server" "" 2097152)
#######################################
sing_box_cm_configure_route() {
    local config="$1"
    local final="$2"
    local auto_detect_interface="$3"
    local default_domain_resolver="$4"
    local default_interface="$5"
    local default_mark="$6"

    echo "$config" | jq \
        --arg final "$final" \
        --argjson auto_detect_interface "$auto_detect_interface" \
        --arg default_domain_resolver "$default_domain_resolver" \
        --arg default_interface "$default_interface" \
        --arg default_mark "$default_mark" \
        '.route = {
            rules: (.route.rules // []),
            rule_set: (.route.rule_set // []),
            final: $final,
            auto_detect_interface: $auto_detect_interface,
            default_domain_resolver: $default_domain_resolver
        }
        + (if $default_interface != "" then { default_interface: $default_interface } else {} end)
        + (if $default_mark != "" then { default_mark: ($default_mark | tonumber) } else {} end)
        '
}

#######################################
# Add a routing rule to the route section of a sing-box JSON configuration.
# Arguments:
#   config: string (JSON), sing-box configuration to modify
#   tag: string, identifier for the route rule
#   inbound: string, inbound tag to match (or a JSON array of tags)
#   outbound: string, outbound tag to route matched traffic to
# Outputs:
#   Writes updated JSON configuration to stdout
# Example:
#   CONFIG=$(sing_box_cm_add_route_rule "$CONFIG" "main-route-rule" "tproxy-in" "main")
#######################################
sing_box_cm_add_route_rule() {
    local config="$1"
    local tag="$2"
    local inbound="$3"
    local outbound="$4"

    echo "$config" | jq \
        --arg service_tag "$SERVICE_TAG" \
        --arg tag "$tag" \
        --argjson inbound "$(_normalize_arg "$inbound")" \
        --arg outbound "$outbound" \
        '.route.rules += [{
            action: "route",
            inbound: $inbound,
            outbound: $outbound,
            $service_tag: $tag
        }]'
}

#######################################
# Add a route rule that sends the traffic of some ports out directly (or, inverted,
# the traffic of every port but those). A single port field and a port_range field in
# one rule would both have to match, so the ports and the ranges are put in a
# logical OR rule of their own.
# Arguments:
#   config: string (JSON), sing-box configuration to modify
#   tag: string, identifier for the route rule
#   inbound: string, inbound tag to match (or a JSON array of tags)
#   network: "tcp" or "udp"
#   ports: comma separated single ports ("80,443"), may be empty
#   ranges: comma separated ranges ("1000:2000"), may be empty
#   invert: "true" to route the traffic of the ports NOT listed
#   outbound: string, outbound tag
# Outputs:
#   Updated JSON config to stdout
#######################################
sing_box_cm_add_port_route_rule() {
    local config="$1"
    local tag="$2"
    local inbound="$3"
    local network="$4"
    local ports="$5"
    local ranges="$6"
    local invert="$7"
    local outbound="$8"

    echo "$config" | jq \
        --arg service_tag "$SERVICE_TAG" \
        --arg tag "$tag" \
        --argjson inbound "$(_normalize_arg "$inbound")" \
        --arg network "$network" \
        --arg ports "$ports" \
        --arg ranges "$ranges" \
        --arg invert "$invert" \
        --arg outbound "$outbound" \
        '.route.rules += [(
            ([(if $ports != "" then {port: ($ports | split(",") | map(tonumber))} else empty end),
              (if $ranges != "" then {port_range: ($ranges | split(","))} else empty end)]) as $matchers
            | {
                type: "logical",
                mode: "and",
                rules: [
                    {inbound: $inbound, network: $network},
                    ({type: "logical", mode: "or", rules: $matchers}
                     + (if $invert == "true" then {invert: true} else {} end))
                ],
                action: "route",
                outbound: $outbound,
                $service_tag: $tag
            }
        )]'
}

#######################################
# Add a route rule that sends BitTorrent traffic out directly instead of through
# the tunnel. BitTorrent is matched on the SNIFFED protocol, so the caller MUST
# insert this rule AFTER the sniff rule in route.rules: placed earlier, the
# protocol is not known yet when the rule is evaluated and it silently never
# matches.
# Arguments:
#   config: string (JSON), sing-box configuration to modify
#   tag: string, identifier for the route rule
#   inbound: string, inbound tag to match (or a JSON array of tags)
#   outbound: string, outbound tag the BitTorrent traffic is routed to
# Outputs:
#   Writes updated JSON configuration to stdout
# Example:
#   CONFIG=$(sing_box_cm_add_bittorrent_direct_route_rule "$CONFIG" "bittorrent-direct-rule-tag" "tproxy-in" "direct-out")
#######################################
sing_box_cm_add_bittorrent_direct_route_rule() {
    local config="$1"
    local tag="$2"
    local inbound="$3"
    local outbound="$4"

    config=$(sing_box_cm_add_route_rule "$config" "$tag" "$inbound" "$outbound")
    config=$(sing_box_cm_patch_route_rule "$config" "$tag" "protocol" "bittorrent")

    echo "$config"
}

#######################################
# Insert a resolve rule immediately before a route rule.
# Copies rule_set from the target route rule.
# Arguments:
#   config: string (JSON), sing-box configuration to modify
#   route_rule_tag: string, tag of the route rule to precede
#   resolve_rule_tag: string, tag for the new resolve rule
#   server: string, DNS server tag (optional, default: "dns-server")
# Outputs:
#   Updated JSON config to stdout
#######################################
sing_box_cm_add_resolve_rule() {
    local config="$1"
    local route_rule_tag="$2"
    local resolve_rule_tag="$3"
    local server="${4:-dns-server}"

    echo "$config" | jq \
        --arg service_tag "$SERVICE_TAG" \
        --arg route_tag "$route_rule_tag" \
        --arg resolve_tag "$resolve_rule_tag" \
        --arg server "$server" \
        '.route.rules |= [
            .[] | 
            if .[$service_tag] == $route_tag then
                {
                    action: "resolve",
                    rule_set: (.rule_set // []),
                    server: $server,
                    ($service_tag): $resolve_tag
                }, .
            else .
            end
        ]'
}

#######################################
# Patch a routing rule in the route section of a sing-box JSON configuration.
# Arguments:
#   config: string (JSON), sing-box configuration to modify
#   tag: string, identifier of the route rule to patch
#   key: string, the key in the rule to update or add
#   value: string (JSON), value to assign to the key
# Outputs:
#   Writes updated JSON configuration to stdout
# Example:
#   CONFIG=$(sing_box_cm_patch_route_rule "$CONFIG" "main-route-rule" "rule_set" "inline-ruleset")
#######################################
sing_box_cm_patch_route_rule() {
    local config="$1"
    local tag="$2"
    local key="$3"
    local value="$4"

    value=$(_normalize_arg "$value")

    echo "$config" | jq \
        --arg service_tag "$SERVICE_TAG" \
        --arg tag "$tag" \
        --arg key "$key" \
        --argjson value "$value" \
        'import "helpers" as h {"search": "/usr/lib/netshift"};
        .route.rules |= map(
            if .[$service_tag] == $tag then
                if has($key) then
                    .[$key] |= h::extend_key_value(.; $value)
                else
                    . + { ($key): $value }
                end
            else
                .
            end
        )'
}

#######################################
# Add a reject rule to the route section of a sing-box JSON configuration.
# Arguments:
#   config: string (JSON), sing-box configuration to modify
#   key: string, the key to set for the reject rule
#   value: string (JSON), value to assign to the key
# Outputs:
#   Writes updated JSON configuration to stdout
# Example:
#   CONFIG=$(sing_box_cm_add_reject_route_rule "$CONFIG" "reject-rule-tag")
#######################################
sing_box_cm_add_reject_route_rule() {
    local config="$1"
    local tag="$2"
    local inbound="$3"

    echo "$config" | jq \
        --arg service_tag "$SERVICE_TAG" \
        --arg tag "$tag" \
        --argjson inbound "$(_normalize_arg "$inbound")" \
        '.route.rules += [{
            action: "reject",
            inbound: $inbound,
            $service_tag: $tag
        }]'
}

#######################################
# Add a DoH blocking reject route rule with an inline ruleset containing known
# public DoH server IP ranges.
# Arguments:
#   config: string (JSON), sing-box configuration to modify
#   tag: string, identifier for the route rule and ruleset
#   inbound: string, inbound tag to match (or a JSON array of tags)
#   doh_ipv4_cidrs: string, space-separated IPv4 CIDRs to block
#   doh_ipv6_cidrs: string, space-separated IPv6 CIDRs to block
# Outputs:
#   Writes updated JSON configuration to stdout
#######################################
sing_box_cm_add_doh_block_route_rule() {
    local config="$1"
    local tag="$2"
    local inbound="$3"
    local doh_ipv4_cidrs="$4"
    local doh_ipv6_cidrs="${5:-}"

    local ruleset_tag cidrs_json
    ruleset_tag="${tag}-ruleset"
    cidrs_json=$(printf '%s %s' "$doh_ipv4_cidrs" "$doh_ipv6_cidrs" | jq -R 'split(" ") | map(select(. != ""))')

    config=$(echo "$config" | jq \
        --arg tag "$ruleset_tag" \
        --argjson ip_cidr "$cidrs_json" \
        '.route.rule_set += [{
            type: "inline",
            tag: $tag,
            rules: [{ ip_cidr: $ip_cidr }]
        }]')

    echo "$config" | jq \
        --arg service_tag "$SERVICE_TAG" \
        --arg tag "$tag" \
        --argjson inbound "$(_normalize_arg "$inbound")" \
        --arg ruleset_tag "$ruleset_tag" \
        '.route.rules += [{
            action: "reject",
            inbound: $inbound,
            rule_set: $ruleset_tag,
            $service_tag: $tag
        }]'
}

#######################################
# Add a hijack-dns rule to the route section of a sing-box JSON configuration.
# Arguments:
#   config: string (JSON), sing-box configuration to modify
#   key: string, the key to set for the hijack-dns rule
#   value: string (JSON), value to assign to the key
# Outputs:
#   Writes updated JSON configuration to stdout
# Example:
#   CONFIG=$(sing_box_cm_add_hijack_dns_route_rule "$CONFIG" "protocol" "dns")
#######################################
sing_box_cm_add_hijack_dns_route_rule() {
    local config="$1"
    local key="$2"
    local value="$3"

    value=$(_normalize_arg "$value")

    echo "$config" | jq \
        --arg key "$key" \
        --argjson value "$value" \
        '.route.rules += [{
            action: "hijack-dns",
            ($key): $value
        }]'
}

#######################################
# Add a route-options rule to the route section of a sing-box JSON configuration.
# Arguments:
#   config: string (JSON), sing-box configuration to modify
#   tag: string, identifier for the route-options rule
# Outputs:
#   Writes updated JSON configuration to stdout
# Example:
#   CONFIG=$(sing_box_cm_add_options_route_rule "$CONFIG" "override-fakeip-port")
#######################################
sing_box_cm_add_options_route_rule() {
    local config="$1"
    local tag="$2"

    echo "$config" | jq \
        --arg service_tag "$SERVICE_TAG" \
        --arg tag "$tag" \
        '.route.rules += [{
            action: "route-options",
            $service_tag: $tag
        }]'
}

#######################################
# Add a sniff rule to the route section of a sing-box JSON configuration.
# Arguments:
#   config: string (JSON), sing-box configuration to modify
#   key: string, the key to set for the sniff rule
#   value: string (JSON), value to assign to the key
# Outputs:
#   Writes updated JSON configuration to stdout
# Example:
#   CONFIG=$(sing_box_cm_sniff_route_rule "$CONFIG" "inbound" "tproxy-in")
#   CONFIG=$(sing_box_cm_sniff_route_rule "$CONFIG" "inbound" '["tproxy-in","dns-in"]')
#######################################
sing_box_cm_sniff_route_rule() {
    local config="$1"
    local key="$2"
    local value="$3"

    value=$(_normalize_arg "$value")

    echo "$config" | jq \
        --arg key "$key" \
        --argjson value "$value" \
        '.route.rules += [{
            action: "sniff",
            ($key): $value
        }]'
}

#######################################
# Add an inline ruleset to the route.rule_set section of a sing-box JSON configuration.
# Arguments:
#   config: string (JSON), sing-box configuration to modify
#   tag: string, identifier for the inline ruleset
# Outputs:
#   Writes updated JSON configuration to stdout
# Example:
#   CONFIG=$(sing_box_cm_add_inline_ruleset "$CONFIG" "inline-ruleset")
#######################################
sing_box_cm_add_inline_ruleset() {
    local config="$1"
    local tag="$2"

    echo "$config" | jq \
        --arg tag "$tag" \
        '.route.rule_set += [{
            type: "inline",
            tag: $tag
        }]'
}

#######################################
# Add or update a rule in an inline ruleset within the route.rule_set section of a sing-box JSON configuration.
# Arguments:
#   config: string (JSON), sing-box configuration to modify
#   tag: string, identifier of the inline ruleset
#   key: string, the key in the ruleset to update or add
#   value: string (JSON), value to assign to the key
# Outputs:
#   Writes updated JSON configuration to stdout
# Example:
#   CONFIG=$(sing_box_cm_add_inline_ruleset_rule "$CONFIG" "inline-ruleset" "domain_suffix" "telegram.org")
#   CONFIG=$(sing_box_cm_add_inline_ruleset_rule "$CONFIG" "inline-ruleset" "domain_suffix" "discord.com")
#   CONFIG=$(sing_box_cm_add_inline_ruleset_rule "$CONFIG" "inline-ruleset" "ip_cidr" "111.111.111.111/32")
#######################################
sing_box_cm_add_inline_ruleset_rule() {
    local config="$1"
    local tag="$2"
    local key="$3"
    local value="$4"

    value=$(_normalize_arg "$value")

    echo "$config" | jq -L /usr/lib/netshift \
        --arg tag "$tag" \
        --arg key "$key" \
        --argjson value "$value" \
        'import "helpers" as h {"search": "/usr/lib/netshift"};
        .route.rule_set |= map(
            if .tag == $tag then
                if has($key) then
                    .[$key] |= h::extend_key_value(.; $value)
                else
                    . + { ($key): $value }
                end
            else
                .
            end
        )'
}

#######################################
# Add a local ruleset to the route.rule_set section of a sing-box JSON configuration.
# Arguments:
#   config: string (JSON), sing-box configuration to modify
#   tag: string, identifier for the local ruleset
#   format: string, format of the local ruleset ("source" or "binary")
#   path: string, file path to the local ruleset
# Outputs:
#   Writes updated JSON configuration to stdout
# Example:
#   CONFIG=$(sing_box_cm_add_local_ruleset "$CONFIG" "local-source-ruleset" "source" "/tmp/local-ruleset.json")
#   CONFIG=$(sing_box_cm_add_local_ruleset "$CONFIG" "local-binary-ruleset" "binary" "/tmp/local-ruleset.srs")
#######################################
sing_box_cm_add_local_ruleset() {
    local config="$1"
    local tag="$2"
    local format="$3"
    local path="$4"

    echo "$config" | jq \
        --arg tag "$tag" \
        --arg format "$format" \
        --arg path "$path" \
        '.route.rule_set += [{
            type: "local",
            tag: $tag,
            format: $format,
            path: $path
        }]'
}

#######################################
# Add a remote ruleset to the route.rule_set section of a sing-box JSON configuration.
# Arguments:
#   config: string (JSON), sing-box configuration to modify
#   tag: string, identifier for the remote ruleset
#   format: string, format of the remote ruleset ("source" or "binary")
#   url: string, URL to download the ruleset from
#   download_detour: string, detour tag for downloading (optional)
#   update_interval: string, update interval for the ruleset (optional)
# Outputs:
#   Writes updated JSON configuration to stdout
# Example:
#   CONFIG=$(sing_box_cm_add_remote_ruleset "$CONFIG" "remote-source-ruleset" "source" "https://example.com/telegram.json")
#######################################
sing_box_cm_add_remote_ruleset() {
    local config="$1"
    local tag="$2"
    local format="$3"
    local url="$4"
    local download_detour="$5"
    local update_interval="$6"

    echo "$config" | jq \
        --arg tag "$tag" \
        --arg format "$format" \
        --arg url "$url" \
        --arg download_detour "$download_detour" \
        --arg update_interval "$update_interval" \
        '.route.rule_set += [(
            {
                type: "remote",
                tag: $tag,
                format: $format,
                url: $url
            }
            + (if $download_detour != "" then { download_detour: $download_detour } else {} end)
            + (if $update_interval != "" then { update_interval: $update_interval } else {} end)
        )]'

}

#######################################
# Configure the experimental cache_file section of a sing-box JSON configuration.
# Arguments:
#   config: string (JSON), sing-box configuration to modify
#   enabled: boolean, enable or disable file caching
#   path: string, file path for cache storage
#   store_fakeip: boolean, whether to store fake IPs in the cache
# Outputs:
#   Writes updated JSON configuration to stdout
# Example:
#   CONFIG=$(sing_box_cm_configure_cache_file "$CONFIG" true "/tmp/cache.db" true)
#######################################
sing_box_cm_configure_cache_file() {
    local config="$1"
    local enabled="$2"
    local path="$3"
    local store_fakeip="$4"

    echo "$config" | jq \
        --argjson enabled "$enabled" \
        --arg path "$path" \
        --argjson store_fakeip "$store_fakeip" \
        '.experimental.cache_file = {
            enabled: $enabled,
            path: $path,
            store_fakeip: $store_fakeip
        }'
}

#######################################
# Configure the experimental clash_api section of a sing-box JSON configuration.
# Arguments:
#   config: string (JSON), sing-box configuration to modify
#   external_controller: string, API listening address; Clash API will be disabled if empty
#   external_ui: string, path to static web resources to serve at http://{{external-controller}}/ui (optional)
#   secret: string, secret for the RESTful API Authenticate by specifying HTTP header (optional)
# Outputs:
#   Writes updated JSON configuration to stdout
# Example:
#   CONFIG=$(sing_box_cm_configure_clash_api "$CONFIG" "192.168.1.1:9090" "ui")
#######################################
sing_box_cm_configure_clash_api() {
    local config="$1"
    local external_controller="$2"
    local external_ui="$3"
    local secret="$4"

    echo "$config" | jq \
        --arg external_controller "$external_controller" \
        --arg external_ui "$external_ui" \
        --arg secret "$secret" \
        '.experimental.clash_api = {
            external_controller: $external_controller,
        }
        + (if $external_ui != "" then { external_ui: $external_ui } else {} end)
        + (if $secret != "" then { secret: $secret } else {} end)'
}

#######################################
# Save a sing-box JSON configuration to a file, removing service-specific tags.
# Arguments:
#   config: string (JSON), sing-box configuration to modify
#   file_path: string, path to save the configuration file
# Outputs:
#   Writes the cleaned JSON configuration to the specified file
# Example:
#   sing_box_cm_save_config_to_file "$CONFIG" "/tmp/sing-box-config.json"
#######################################
sing_box_cm_save_config_to_file() {
    local config="$1"
    local filepath="$2"

    echo "$config" | jq \
        --arg tag "$SERVICE_TAG" \
        'walk(if type == "object" then del(.[$tag]) else . end)' \
        > "$filepath"
}

# Converts a duration sing-box understands ("3m", "1h", "8760h", "90s", or a
# bare number of seconds) to seconds; prints nothing when it cannot be parsed.
# Lives here, next to its only caller, because the config manager is also used on
# its own (the smoke suite sources it without the rest of the libraries).
_duration_to_seconds() {
    local value="$1"
    local number unit

    case "$value" in
    '' | *[!0-9smhd]*) return 1 ;;
    esac

    number="${value%[smhd]}"
    unit="${value#"$number"}"
    case "$number" in
    '' | *[!0-9]*) return 1 ;;
    esac

    case "$unit" in
    '' | s) : ;;
    m) number=$((number * 60)) ;;
    h) number=$((number * 3600)) ;;
    d) number=$((number * 86400)) ;;
    *) return 1 ;;
    esac

    printf '%s\n' "$number"
}

_normalize_arg() {
    local value="$1"
    if [ -z "$value" ]; then
        printf '""'
    elif echo "$value" | jq -e . > /dev/null 2>&1; then
        printf '%s' "$value"
    else
        printf '%s' "$value" | jq -R .
    fi
}

#######################################
# Insert a resolve rule with no conditions yet immediately before a route rule. The conditions
# (rule_set) are added later with sing_box_cm_patch_route_rule under the new rule's tag; a rule
# left without any must be removed by the caller, it would match every connection.
# Arguments:
#   config: string (JSON), sing-box configuration to modify
#   before_tag: string, service tag of the route rule to precede
#   resolve_rule_tag: string, service tag of the new resolve rule
#   server: string, DNS server tag the domains are resolved through
# Outputs:
#   Updated JSON config to stdout
#######################################
sing_box_cm_add_resolve_rule_before() {
    local config="$1"
    local before_tag="$2"
    local resolve_rule_tag="$3"
    local server="$4"

    echo "$config" | jq \
        --arg service_tag "$SERVICE_TAG" \
        --arg before "$before_tag" \
        --arg resolve_tag "$resolve_rule_tag" \
        --arg server "$server" \
        '.route.rules |= [
            .[] |
            if .[$service_tag] == $before then
                { action: "resolve", server: $server, ($service_tag): $resolve_tag }, .
            else .
            end
        ]'
}
