"use strict";
"require form";
"require baseclass";
"require ui";
"require uci";
"require tools.widgets as widgets";
"require view.netshift_ea5babe5.main as main";

// Ready-made remote lists that only make sense in a Block section.
const REMOTE_BLOCK_LISTS = [
  "https://raw.githubusercontent.com/SagerNet/sing-geosite/rule-set/geosite-category-ads-all.srs",
  "https://raw.githubusercontent.com/SagerNet/sing-geosite/rule-set/geosite-category-ads.srs",
  "https://raw.githubusercontent.com/SagerNet/sing-geosite/rule-set/geosite-category-public-tracker.srs",
];

function createSectionContent(section) {
  // Group the 36 connection options into 4 native CBI option-group tabs.
  // HARD RULE: once a section has tab(), every option MUST be added via
  // taboption() — any leftover section.option(...) renders nothing.
  // depends() works across tabs; a tab whose options are all depends-hidden
  // auto-hides from the strip (desired, e.g. Subscription for proxy/url).
  section.tab(
    "connection",
    _("Connection"),
    _("Connection type, transport and DNS resolver for this section"),
  );
  section.tab(
    "subscription",
    _("Subscription"),
    _("Subscription feeds, server filters and URLTest tuning"),
  );
  section.tab(
    "routing",
    _("Routing"),
    _("Domain and subnet lists that decide which traffic uses this section"),
  );
  section.tab(
    "advanced",
    _("Advanced"),
    _("Mixed proxy and DNS resolution tuning"),
  );

  let o = section.taboption(
    "connection",
    form.ListValue,
    "connection_type",
    _("Connection Type"),
    _(
      "Proxy and VPN send the traffic of the lists through a tunnel, Block drops it, Exclusion sends it out directly, DNS answers the domains of the lists from its own DNS server.",
    ),
  );
  o.value("proxy", _("Proxy"));
  o.value("vpn", "VPN");
  o.value("block", _("Block"));
  o.value("exclusion", _("Exclusion"));
  o.value("dns", _("DNS (own DNS server for the domains)"));

  o = section.taboption(
    "connection",
    form.ListValue,
    "dns_type",
    _("DNS Protocol Type"),
    _("Protocol of this section's own DNS server"),
  );
  o.value("udp", _("UDP (Unprotected DNS)"));
  o.value("tcp", _("TCP"));
  o.value("dot", _("DNS over TLS (DoT)"));
  o.value("doh", _("DNS over HTTPS (DoH)"));
  o.value("doh3", _("DNS over HTTP/3 (DoH3)"));
  o.value("doq", _("DNS over QUIC (DoQ)"));
  o.default = "udp";
  o.depends("connection_type", "dns");
  o.rmempty = false;

  o = section.taboption(
    "connection",
    form.Value,
    "dns_server",
    _("DNS Server"),
    _(
      "The domains of this section's lists are resolved by this server instead of the main one and are not sent through any tunnel (split DNS). Address, address:port or host/path for DoH",
    ),
  );
  Object.entries(main.DNS_SERVER_OPTIONS).forEach(([key, label]) => {
    o.value(key, _(label));
  });
  o.value("77.88.8.8", _("77.88.8.8 (Yandex)"));
  o.value("common.dot.dns.yandex.net", _("common.dot.dns.yandex.net (Yandex DoT)"));
  o.value("common.dns.yandex.net/dns-query", _("common.dns.yandex.net/dns-query (Yandex DoH)"));
  o.value("dns.google/dns-query", _("dns.google/dns-query (Google DoH)"));
  o.value("cloudflare-dns.com/dns-query", _("cloudflare-dns.com/dns-query (Cloudflare DoH)"));
  o.value("dns.quad9.net/dns-query", _("dns.quad9.net/dns-query (Quad9 DoH)"));
  o.value("dns.adguard-dns.com/dns-query", _("dns.adguard-dns.com/dns-query (AdGuard DoH)"));
  o.depends("connection_type", "dns");
  o.rmempty = false;
  o.validate = function (section_id, value) {
    const validation = main.validateDNS(value);

    if (validation.valid) {
      return true;
    }

    return validation.message;
  };

  o = section.taboption(
    "connection",
    form.DynamicList,
    "dns_pool_server",
    _("Additional DNS servers"),
    _(
      "More servers for this section, any mix of udp, tcp, dot, doh, doh3 and doq: scheme://host[:port][/path]. Used together with the server above as the mode below says. Pick a ready-made server or type your own.",
    ),
  );
  Object.entries(main.DNS_POOL_PRESETS).forEach(([key, label]) => {
    o.value(key, label);
  });
  o.depends("connection_type", "dns");
  o.rmempty = true;
  // Servers added to the list are ignored in "first server only" mode: when the list grows,
  // switch to priority (the user can still pick another mode below), as the DNS settings do.
  const poolKnownCount = {};
  o.onchange = function (ev, section_id, value) {
    const count = Array.isArray(value) ? value.length : 0;
    const grew =
      poolKnownCount[section_id] !== undefined &&
      count > poolKnownCount[section_id];

    poolKnownCount[section_id] = count;

    if (!grew) {
      return;
    }

    const mode = this.section.getUIElement(section_id, "dns_pool_mode");

    if (mode && mode.getValue() === "single") {
      mode.setValue("fallback");
    }
  };
  o.validate = function (section_id, value) {
    if (!value) {
      return true;
    }

    const validation = main.validateDnsPoolServer(value);

    return validation.valid ? true : validation.message;
  };

  o = section.taboption(
    "connection",
    form.ListValue,
    "dns_pool_mode",
    _("Several DNS servers"),
    _(
      "How the servers of the list are used together when there are several. Needs sing-box 1.14 or newer; on an older core only the first server is used.",
    ),
  );
  o.value("single", _("First server only"));
  o.value("fallback", _("Priority: next server if the previous one fails"));
  o.value("race", _("Parallel: the first usable answer wins"));
  o.default = "single";
  o.depends("connection_type", "dns");
  o.rmempty = false;

  o = section.taboption(
    "connection",
    form.Value,
    "dns_pool_timeout",
    _("DNS server timeout"),
    _(
      "How long one DNS server may take before the next one is tried (priority) or its answer is dropped (parallel). Examples: 500ms, 2s",
    ),
  );
  o.depends({ connection_type: "dns", dns_pool_mode: "fallback" });
  o.depends({ connection_type: "dns", dns_pool_mode: "race" });
  o.default = "2s";
  o.rmempty = false;
  o.validate = function (section_id, value) {
    const validation = main.validateDnsPoolTimeout(value);

    return validation.valid ? true : validation.message;
  };

  o = section.taboption(
    "connection",
    form.ListValue,
    "dns_detour_section",
    _("Send DNS queries through section"),
    _(
      "Optional: query this DNS server through the outbound of another section. If that outbound is not usable the queries go out directly.",
    ),
  );
  o.depends("connection_type", "dns");
  o.rmempty = true;
  o.load = function (section_id) {
    const sections = this.map?.data?.state?.values?.netshift ?? {};

    this.keylist = [""];
    this.vallist = [_("Directly")];

    for (const secName in sections) {
      const sec = sections[secName];
      if (
        secName !== section_id &&
        sec[".type"] === "section" &&
        (sec["connection_type"] === "proxy" || sec["connection_type"] === "vpn")
      ) {
        this.keylist.push(secName);
        this.vallist.push(secName);
      }
    }

    return form.ListValue.prototype.load.apply(this, arguments);
  };

  o = section.taboption(
    "connection",
    form.ListValue,
    "proxy_config_type",
    _("Configuration Type"),
    _("Select how to configure the proxy"),
  );
  o.value("url", _("Connection URL"));
  o.value("selector", _("Selector"));
  o.value("urltest", _("URLTest"));
  o.value("selector_text", _("Selector (text list)"));
  o.value("urltest_text", _("URLTest (text list)"));
  o.value("subscription", _("Subscription"));
  o.value("outbound", _("Outbound Config"));
  o.default = "url";
  o.depends("connection_type", "proxy");

  o = section.taboption(
    "connection",
    form.TextValue,
    "proxy_string",
    _("Proxy Configuration URL"),
    _(
      "vless://, vmess://, ss://, trojan://, socks4/5://, hy2/hysteria2://, tuic://, anytls://, naive+https:// links",
    ),
  );
  o.depends({ connection_type: "proxy", proxy_config_type: "url" });
  o.rows = 5;
  // Enable soft wrapping for multi-line proxy URLs (e.g., for URLTest proxy links)
  o.wrap = "soft";
  // Render as a textarea to allow multiple proxy URLs/configs
  o.textarea = true;
  o.rmempty = false;
  o.sectionDescriptions = new Map();
  o.validate = function (section_id, value) {
    // Optional
    if (!value || value.length === 0) {
      return true;
    }

    const validation = main.validateProxyUrl(value);

    if (validation.valid) {
      return true;
    }

    return validation.message;
  };

  o = section.taboption(
    "connection",
    form.TextValue,
    "outbound_json",
    _("Outbound Configuration"),
    _("Enter complete outbound configuration in JSON format"),
  );
  o.depends({ connection_type: "proxy", proxy_config_type: "outbound" });
  o.rows = 10;
  o.validate = function (section_id, value) {
    // Optional
    if (!value || value.length === 0) {
      return true;
    }

    const validation = main.validateOutboundJson(value);

    if (validation.valid) {
      return true;
    }

    return validation.message;
  };

  o = section.taboption(
    "subscription",
    form.DynamicList,
    "subscription_url",
    _("Subscription URLs"),
    _(
      "Add one or more subscription URLs to fetch proxy configurations from. All feeds are downloaded and merged.",
    ),
  );
  o.depends({ connection_type: "proxy", proxy_config_type: "subscription" });
  o.placeholder = "https://example.com/api/sub";
  o.rmempty = true;
  o.validate = function (section_id, value) {
    if (!value || value.length === 0) {
      return true;
    }

    const validation = main.validateUrl(value);

    if (validation.valid) {
      return true;
    }

    return validation.message;
  };

  // A published list of feeds (a text file with an address per line, or a JSON object
  // keyed by the addresses): its feeds are put into the list above.
  o = section.taboption(
    "subscription",
    form.DummyValue,
    "_feed_list",
    _("Add feeds from a list"),
    _(
      "The address of a published list of subscriptions: a text file with a feed address per line, or a JSON object whose keys are the addresses. The feeds found are added to the list above (the ones already there are skipped); save and apply to keep them. A feed with thousands of servers is cut to the number below.",
    ),
  );
  o.depends({ connection_type: "proxy", proxy_config_type: "subscription" });
  o.rawhtml = true;
  o.cfgvalue = function (section_id) {
    const input = E("input", {
      class: "cbi-input-text",
      type: "text",
      placeholder: "https://example.com/urls.txt",
      style: "min-width:18em",
    });
    const result = E("div", { class: "ns-muted" });
    const button = E(
      "button",
      {
        class: "btn cbi-button cbi-button-add",
        click: (ev) => {
          ev.preventDefault();

          const address = input.value.trim();

          if (!address) {
            return;
          }

          button.disabled = true;
          result.textContent = _("Downloading the list...");

          main.NetShiftShellMethods.fetchFeedList(address)
            .then((reply) => {
              const answer = reply.success
                ? main.parseFeedList(reply.data)
                : { ok: false, urls: [], error: "" };

              if (!answer.ok) {
                result.textContent = [
                  _("Could not read the list"),
                  answer.error,
                ]
                  .filter(Boolean)
                  .join(": ");
                return;
              }

              const element = this.section.getUIElement(
                section_id,
                "subscription_url",
              );
              const current = element ? element.getValue() : [];
              const existing = Array.isArray(current)
                ? current
                : current
                  ? [current]
                  : [];
              const added = main.newFeeds(existing, answer.urls);

              if (element) {
                element.setValue([...existing, ...added]);
              }

              result.textContent = _(
                "Found %d feeds, added %d. Save and apply to keep them.",
              )
                .format(answer.urls.length, added.length);
            })
            .catch(() => {
              result.textContent = _("Could not read the list");
            })
            .finally(() => {
              button.disabled = false;
            });
        },
      },
      _("Add the feeds"),
    );

    return E("div", {}, [
      E("div", { style: "display:flex;gap:.5em;flex-wrap:wrap" }, [
        input,
        button,
      ]),
      result,
    ]);
  };

  o = section.taboption(
    "subscription",
    form.Value,
    "subscription_max_nodes",
    _("Servers per feed"),
    _(
      "How many servers of one feed are used (the first ones). Published lists hold thousands of servers: each is processed one by one and the group of them is tested by the router, which is too much for it. 0 uses all of them.",
    ),
  );
  o.depends({ connection_type: "proxy", proxy_config_type: "subscription" });
  o.datatype = "uinteger";
  o.placeholder = "500";
  o.default = "500";
  o.rmempty = true;

  o = section.taboption(
    "subscription",
    form.ListValue,
    "subscription_format_preference",
    _("Subscription format"),
    _(
      "Which subscription format (client) to fetch first. Auto uses the default order. Choose Xray JSON (Happ) when your panel only exposes some nodes (e.g. xhttp) under a Happ-like client, or Sing-box to prefer the sing-box format.",
    ),
  );
  o.value("auto", _("Auto"));
  o.value("xray", _("Xray JSON (Happ)"));
  o.value("singbox", _("Sing-box"));
  o.default = "auto";
  o.depends({ connection_type: "proxy", proxy_config_type: "subscription" });

  o = section.taboption(
    "subscription",
    form.Flag,
    "subscription_insecure",
    _("Allow insecure TLS for subscription fetch"),
    _("Disables TLS certificate verification when downloading the subscription.") +
      " " +
      _("Use only for IP-host panels that serve an invalid or self-signed certificate.") +
      " " +
      _("This is a security trade-off: an attacker could intercept the fetch."),
  );
  o.default = "0";
  o.rmempty = false;
  o.depends({ connection_type: "proxy", proxy_config_type: "subscription" });

  // Some panels serve a subscription only to a given app (Happ on Android, INCY on iOS)
  // and check the HWID and device headers it sends; these fields override the router's own.
  o = section.taboption(
    "subscription",
    form.DummyValue,
    "_client_identity",
    _("Generate a client"),
    _(
      "Fills the five fields below the way the chosen app on the chosen platform sends them, with a new HWID. A HWID copied from a real device the subscription is bound to does not take one more device slot.",
    ),
  );
  o.depends({ connection_type: "proxy", proxy_config_type: "subscription" });
  o.rawhtml = true;
  o.cfgvalue = function (section_id) {
    const profiles = main.CLIENT_IDENTITY_PROFILES;
    const platform = E("select", { class: "cbi-input-select" });
    const fillPlatforms = () => {
      platform.replaceChildren(
        ...Object.keys(profiles[app.value]).map((name) =>
          E("option", { value: name }, name),
        ),
      );
    };
    const app = E(
      "select",
      { class: "cbi-input-select", change: fillPlatforms },
      Object.keys(profiles).map((name) => E("option", { value: name }, name)),
    );
    fillPlatforms();

    const button = E(
      "button",
      {
        class: "btn cbi-button cbi-button-action",
        click: (ev) => {
          ev.preventDefault();

          const identity = main.generateClientIdentity(
            app.value,
            platform.value,
          );

          if (!identity) {
            return;
          }

          Object.entries(identity).forEach(([name, value]) => {
            const element = this.section.getUIElement(
              section_id,
              `subscription_${name}`,
            );

            if (element) {
              element.setValue(value);
            }
          });
        },
      },
      _("Generate"),
    );

    return E("div", { style: "display:flex;gap:.5em;flex-wrap:wrap" }, [
      app,
      platform,
      button,
    ]);
  };

  o = section.taboption(
    "subscription",
    form.Value,
    "subscription_user_agent",
    _("Client User-Agent"),
    _(
      "The app the subscription is fetched as, e.g. Happ/4.7.1/Android/<number> or INCY/3.7.9/android Dalvik/2.1.0 (the generator above fills it in). Only this User-Agent is used then. Empty tries well-known clients.",
    ),
  );
  o.placeholder = _("Auto");
  o.rmempty = true;
  o.depends({ connection_type: "proxy", proxy_config_type: "subscription" });

  o = section.taboption(
    "subscription",
    form.Value,
    "subscription_hwid",
    _("HWID"),
    _(
      "Device ID sent to the panel (X-HWID). Copy it from the app on a device the subscription is bound to. Empty uses the router's own ID.",
    ),
  );
  o.placeholder = _("Router's own");
  o.rmempty = true;
  o.validate = function (section_id, value) {
    // The rule of Remnawave: a panel ignores any other X-HWID.
    if (!value || /^[A-Za-z0-9=-]{10,64}$/.test(value)) {
      return true;
    }

    return _("10 to 64 Latin letters, digits, = or -");
  };
  o.depends({ connection_type: "proxy", proxy_config_type: "subscription" });

  o = section.taboption(
    "subscription",
    form.Value,
    "subscription_device_os",
    _("Device OS"),
    _("Sent to the panel as X-Device-OS. Empty sends OpenWrt Linux."),
  );
  o.value("Android", "Android");
  o.value("iOS", "iOS");
  o.value("Windows", "Windows");
  o.value("macOS", "macOS");
  o.placeholder = "OpenWrt Linux";
  o.rmempty = true;
  o.depends({ connection_type: "proxy", proxy_config_type: "subscription" });

  o = section.taboption(
    "subscription",
    form.Value,
    "subscription_os_version",
    _("OS version"),
    _(
      "Sent to the panel as X-Ver-OS, e.g. 14 for Android or 18.3 for iOS. Empty sends the router's kernel version.",
    ),
  );
  o.rmempty = true;
  o.depends({ connection_type: "proxy", proxy_config_type: "subscription" });

  o = section.taboption(
    "subscription",
    form.Value,
    "subscription_device_model",
    _("Device model"),
    _(
      "Sent to the panel as X-Device-Model, e.g. Pixel 8 or iPhone 15. Empty sends the router's model.",
    ),
  );
  o.rmempty = true;
  o.depends({ connection_type: "proxy", proxy_config_type: "subscription" });

  o = section.taboption(
    "subscription",
    form.ListValue,
    "subscription_update_interval",
    _("Subscription Update Interval"),
    _("How often to automatically update the subscription"),
  );
  o.value("30m", _("Every 30 minutes"));
  o.value("1h", _("Every hour"));
  o.value("3h", _("Every 3 hours"));
  o.value("6h", _("Every 6 hours"));
  o.value("12h", _("Every 12 hours"));
  o.value("1d", _("Every day"));
  o.default = "1h";
  o.depends({ connection_type: "proxy", proxy_config_type: "subscription" });

  o = section.taboption(
    "subscription",
    form.Value,
    "subscription_update_time",
    _("Update time"),
    _(
      "Time of the daily update, HH:MM (00:00-23:59) in the router's local time. Avoid minutes shared with other update intervals, such as :00 and :30 if a 30-minute section exists",
    ),
  );
  // The same default as SUBSCRIPTION_UPDATE_TIME_DEFAULT in
  // netshift/files/usr/lib/constants.sh: change both together.
  o.default = "09:52";
  o.placeholder = "09:52";
  o.rmempty = true;
  o.depends({
    connection_type: "proxy",
    proxy_config_type: "subscription",
    subscription_update_interval: "1d",
  });
  o.validate = function (section_id, value) {
    // Empty means "keep the default" (an existing config has no such option)
    if (!value) {
      return true;
    }

    const validation = main.validateTime(value);

    if (validation.valid) {
      return true;
    }

    return validation.message;
  };

  o = section.taboption(
    "subscription",
    form.ListValue,
    "subscription_group_mode",
    _("Subscription grouping"),
    _(
      "Group subscription proxies into URLTest groups. 'By country flag' uses the flag emoji at the start of each name; 'By name prefix' groups by the first N characters.",
    ),
  );
  o.value("off", _("Off"));
  o.value("country", _("By country flag"));
  o.value("prefix", _("By name prefix"));
  o.default = "off";
  o.rmempty = false;
  o.depends({ connection_type: "proxy", proxy_config_type: "subscription" });

  o = section.taboption(
    "subscription",
    form.Value,
    "subscription_group_prefix_len",
    _("Prefix length"),
    _("Number of leading characters of each proxy name to group by."),
  );
  o.default = "2";
  o.datatype = "and(uinteger,min(1))";
  o.rmempty = false;
  o.depends({
    connection_type: "proxy",
    proxy_config_type: "subscription",
    subscription_group_mode: "prefix",
  });

  o = section.taboption(
    "subscription",
    form.DynamicList,
    "subscription_filter_include_keywords",
    _("Include servers by keyword"),
    _(
      "Keep only subscription servers whose name contains at least one of these keywords (case-insensitive). Leave empty to keep all. Several words can be written in one line, separated by | without spaces (NL|DE|Finland).",
    ),
  );
  o.depends({ connection_type: "proxy", proxy_config_type: "subscription" });
  o.rmempty = true;

  o = section.taboption(
    "subscription",
    form.DynamicList,
    "subscription_filter_exclude_keywords",
    _("Exclude servers by keyword"),
    _(
      "Drop subscription servers whose name contains any of these keywords (case-insensitive). Several words can be written in one line, separated by | without spaces (test|expired).",
    ),
  );
  o.depends({ connection_type: "proxy", proxy_config_type: "subscription" });
  o.rmempty = true;

  o = section.taboption(
    "subscription",
    form.DynamicList,
    "subscription_filter_include_countries",
    _("Include servers by country"),
    _(
      "Keep only servers whose name carries the flag of one of these countries. Two-letter codes, for example NL or DE. Combined with the keywords above (any match keeps a server).",
    ),
  );
  o.depends({ connection_type: "proxy", proxy_config_type: "subscription" });
  o.rmempty = true;
  o.validate = function (section_id, value) {
    if (!value || /^[A-Za-z]{2}$/.test(value)) {
      return true;
    }

    return _("Use a two-letter country code, for example NL");
  };

  o = section.taboption(
    "subscription",
    form.DynamicList,
    "subscription_filter_exclude_countries",
    _("Exclude servers by country"),
    _(
      "Drop servers whose name carries the flag of one of these countries. Two-letter codes, for example RU or US.",
    ),
  );
  o.depends({ connection_type: "proxy", proxy_config_type: "subscription" });
  o.rmempty = true;
  o.validate = function (section_id, value) {
    if (!value || /^[A-Za-z]{2}$/.test(value)) {
      return true;
    }

    return _("Use a two-letter country code, for example NL");
  };

  // Filters by how a server connects: protocol, transport, security.
  const paramFilters = [
    {
      kind: "protocols",
      include: _("Include servers by protocol"),
      exclude: _("Exclude servers by protocol"),
      choices: {
        vless: "VLESS",
        vmess: "VMess",
        trojan: "Trojan",
        shadowsocks: "Shadowsocks",
        hysteria2: "Hysteria2",
        tuic: "TUIC",
        socks: "SOCKS",
      },
    },
    {
      kind: "transports",
      include: _("Include servers by transport"),
      exclude: _("Exclude servers by transport"),
      choices: {
        tcp: "TCP",
        ws: "WebSocket",
        grpc: "gRPC",
        http: "HTTP/2",
        httpupgrade: "HTTPUpgrade",
        xhttp: "XHTTP",
      },
    },
    {
      kind: "security",
      include: _("Include servers by security"),
      exclude: _("Exclude servers by security"),
      choices: {
        reality: "Reality",
        tls: "TLS",
        none: _("No encryption layer"),
      },
    },
  ];

  const paramFilterOptionNames = [
    "subscription_filter_include_keywords",
    "subscription_filter_exclude_keywords",
    "subscription_filter_include_countries",
    "subscription_filter_exclude_countries",
  ];

  paramFilters.forEach(({ kind, include, exclude, choices }) => {
    paramFilterOptionNames.push(
      `subscription_filter_include_${kind}`,
      `subscription_filter_exclude_${kind}`,
    );
    [
      ["include", include, _("Keep only servers that connect this way.")],
      ["exclude", exclude, _("Drop servers that connect this way.")],
    ].forEach(([direction, title, description]) => {
      o = section.taboption(
        "subscription",
        form.DynamicList,
        `subscription_filter_${direction}_${kind}`,
        title,
        `${description} ${_("Combined with the other filters: a server has to pass all of them.")}`,
      );
      Object.entries(choices).forEach(([value, label]) => o.value(value, label));
      o.depends({ connection_type: "proxy", proxy_config_type: "subscription" });
      o.rmempty = true;
    });
  });

  // How many servers the filters above keep, before saving: the form values go to the
  // router, which applies them to the subscription it downloaded at the last start.
  o = section.taboption(
    "subscription",
    form.DummyValue,
    "_subscription_filter_preview",
    _("Filter preview"),
    _(
      "Shows how many servers of the downloaded subscription the filters above keep, and which. Nothing is saved or changed.",
    ),
  );
  o.rawhtml = true;
  o.depends({ connection_type: "proxy", proxy_config_type: "subscription" });
  o.cfgvalue = function (section_id) {
    const widget = this;
    // not cbi-value-description: themes put a help icon in front of every such line
    const result = E("div", { style: "margin-top:.4em" });
    const button = E(
      "button",
      {
        class: "btn cbi-button",
        click: (ev) => {
          ev.preventDefault();

          const overrides = {};

          // The live value of the widget, as _feed_list reads it. A field that cannot be read
          // is left out (the saved value is then used), never sent as an empty list: that
          // would clear the filter and show "everything stays".
          paramFilterOptionNames.forEach((name) => {
            const element = widget.section.getUIElement(section_id, name);

            if (!element) {
              return;
            }

            const value = element.getValue();

            // a widget with no value to give is skipped too: an empty list would clear the filter
            if (value == null) {
              return;
            }

            overrides[name] = (Array.isArray(value) ? value : [value]).filter(Boolean);
          });

          button.disabled = true;
          result.textContent = _("Checking...");

          main.NetShiftShellMethods.previewSubscriptionFilter(
            section_id,
            JSON.stringify(overrides),
          )
            .then((reply) => {
              // callBaseMethod has parsed the JSON of the command already
              const data = reply.success ? reply.data : null;

              if (!data) {
                result.textContent = _("The check could not be run");
              } else if (data.error === "no_cache") {
                result.textContent = _(
                  "There is no downloaded subscription yet: save the settings and restart the service first.",
                );
              } else if (data.error === "no_section") {
                result.textContent = _("The section is not saved yet: save it first.");
              } else if (data.error === "disabled") {
                result.textContent = _("The section is disabled: it gives no servers.");
              } else if (data.error) {
                result.textContent = _("The check could not be run");
              } else {
                result.replaceChildren(
                  E("div", { style: "font-weight:600" }, `${_("Kept")}: ${data.kept} / ${data.total}`),
                  data.kept === 0
                    ? E(
                        "div",
                        { style: "color:var(--error-color-medium, #dc3545)" },
                        _("No server is left: the section would have no connection."),
                      )
                    : E("div", {}, (data.names ?? []).slice(0, 50).join(", ")),
                  data.kept > 50 ? E("div", {}, `… ${data.kept - 50}`) : "",
                  data.unsupported > 0
                    ? E(
                        "div",
                        { style: "opacity:.75;font-size:90%" },
                        _("%d servers cannot be used by this core whatever the filters say.").format(data.unsupported),
                      )
                    : "",
                );
              }
            })
            .catch(() => {
              result.textContent = _("The check could not be run");
            })
            .finally(() => {
              button.disabled = false;
            });
        },
      },
      _("Check the filters"),
    );

    return E("div", {}, [button, result]);
  };

  o = section.taboption(
    "connection",
    form.DynamicList,
    "selector_proxy_links",
    _("Selector Proxy Links"),
    _(
      "vless://, vmess://, ss://, trojan://, socks4/5://, hy2/hysteria2://, tuic://, anytls://, naive+https:// links",
    ),
  );
  o.depends({ connection_type: "proxy", proxy_config_type: "selector" });
  o.rmempty = false;
  o.validate = function (section_id, value) {
    // Optional
    if (!value || value.length === 0) {
      return true;
    }

    const validation = main.validateProxyUrl(value);

    if (validation.valid) {
      return true;
    }

    return validation.message;
  };

  o = section.taboption(
    "connection",
    form.TextValue,
    "selector_proxy_links_text",
    _("Selector Proxy Links (one per line)"),
    _(
      "vless://, vmess://, ss://, trojan://, socks4/5://, hy2/hysteria2://, tuic://, anytls://, naive+https:// links — one per line",
    ),
  );
  o.depends({ connection_type: "proxy", proxy_config_type: "selector_text" });
  o.rows = 5;
  o.wrap = "soft";
  o.textarea = true;
  o.rmempty = false;
  o.validate = function (section_id, value) {
    // Optional
    if (!value || value.length === 0) {
      return true;
    }

    const validation = main.validateProxyUrlList(value);

    if (validation.valid) {
      return true;
    }

    return validation.message;
  };

  o = section.taboption(
    "subscription",
    form.DynamicList,
    "urltest_proxy_links",
    _("URLTest Proxy Links"),
    _(
      "vless://, vmess://, ss://, trojan://, socks4/5://, hy2/hysteria2://, tuic://, anytls://, naive+https:// links",
    ),
  );
  o.depends({ connection_type: "proxy", proxy_config_type: "urltest" });
  o.rmempty = false;
  o.validate = function (section_id, value) {
    // Optional
    if (!value || value.length === 0) {
      return true;
    }

    const validation = main.validateProxyUrl(value);

    if (validation.valid) {
      return true;
    }

    return validation.message;
  };

  o = section.taboption(
    "subscription",
    form.TextValue,
    "urltest_proxy_links_text",
    _("URLTest Proxy Links (one per line)"),
    _(
      "vless://, vmess://, ss://, trojan://, socks4/5://, hy2/hysteria2://, tuic://, anytls://, naive+https:// links — one per line",
    ),
  );
  o.depends({ connection_type: "proxy", proxy_config_type: "urltest_text" });
  o.rows = 5;
  o.wrap = "soft";
  o.textarea = true;
  o.rmempty = false;
  o.validate = function (section_id, value) {
    // Optional
    if (!value || value.length === 0) {
      return true;
    }

    const validation = main.validateProxyUrlList(value);

    if (validation.valid) {
      return true;
    }

    return validation.message;
  };

  o = section.taboption(
    "subscription",
    form.ListValue,
    "urltest_check_interval",
    _("URLTest Check Interval"),
    _("The interval between connectivity tests. A longer interval means less traffic through every server of the group; \"Only at start\" tests once when the service starts."),
  );
  o.value("30s", _("Every 30 seconds"));
  o.value("1m", _("Every 1 minute"));
  o.value("3m", _("Every 3 minutes"));
  o.value("5m", _("Every 5 minutes"));
  o.value("10m", _("Every 10 minutes"));
  o.value("20m", _("Every 20 minutes"));
  o.value("30m", _("Every 30 minutes"));
  o.value("1h", _("Every hour"));
  o.value("6h", _("Every 6 hours"));
  o.value("24h", _("Every 24 hours"));
  o.value("off", _("Only at start, never again"));
  o.default = "3m";
  o.depends({ connection_type: "proxy", proxy_config_type: "urltest" });
  o.depends({ connection_type: "proxy", proxy_config_type: "urltest_text" });
  o.depends({ connection_type: "proxy", proxy_config_type: "subscription" });

  o = section.taboption(
    "subscription",
    form.Value,
    "urltest_tolerance",
    _("URLTest Tolerance"),
    _(
      "The maximum difference in response times (ms) allowed when comparing servers",
    ),
  );
  o.default = "50";
  o.rmempty = false;
  o.depends({ connection_type: "proxy", proxy_config_type: "urltest" });
  o.depends({ connection_type: "proxy", proxy_config_type: "urltest_text" });
  o.depends({ connection_type: "proxy", proxy_config_type: "subscription" });
  o.validate = function (section_id, value) {
    if (!value || value.length === 0) {
      return true;
    }

    const parsed = parseFloat(value);

    if (
      /^[0-9]+$/.test(value) &&
      !isNaN(parsed) &&
      isFinite(parsed) &&
      parsed >= 50 &&
      parsed <= 1000
    ) {
      return true;
    }

    return _("Must be a number in the range of 50 - 1000");
  };

  o = section.taboption(
    "subscription",
    form.Value,
    "urltest_testing_url",
    _("URLTest Testing URL"),
    _("The URL used to test server connectivity"),
  );
  o.value(
    "https://www.gstatic.com/generate_204",
    "https://www.gstatic.com/generate_204 (Google)",
  );
  o.value(
    "https://cp.cloudflare.com/generate_204",
    "https://cp.cloudflare.com/generate_204 (Cloudflare)",
  );
  o.value("https://captive.apple.com", "https://captive.apple.com (Apple)");
  o.value(
    "https://connectivity-check.ubuntu.com",
    "https://connectivity-check.ubuntu.com (Ubuntu)",
  );
  o.default = "https://www.gstatic.com/generate_204";
  o.rmempty = false;
  o.depends({ connection_type: "proxy", proxy_config_type: "urltest" });
  o.depends({ connection_type: "proxy", proxy_config_type: "urltest_text" });
  o.depends({ connection_type: "proxy", proxy_config_type: "subscription" });

  o.validate = function (section_id, value) {
    if (!value || value.length === 0) {
      return true;
    }

    const validation = main.validateUrl(value);

    if (validation.valid) {
      return true;
    }

    return validation.message;
  };

  o = section.taboption(
    "subscription",
    form.Flag,
    "pin_guard",
    _("Leave a dead server chosen by hand"),
    _(
      "When a server picked by hand stops answering (three checks in a row, every 30 seconds), go back to the automatic choice (the fastest server) and say so on the dashboard. Needs the automatic group, so it works with URLTest lists and subscriptions; it does nothing together with the list-order mode.",
    ),
  );
  o.default = "0";
  o.rmempty = false;
  o.depends({ connection_type: "proxy", proxy_config_type: "urltest" });
  o.depends({ connection_type: "proxy", proxy_config_type: "urltest_text" });
  o.depends({ connection_type: "proxy", proxy_config_type: "subscription" });

  o = section.taboption(
    "subscription",
    form.Flag,
    "priority_mode",
    _("Prefer servers in list order"),
    _(
      "Use the first server of the list that works and go back to a higher one as soon as it recovers (checked every 30 seconds). Unlike URLTest this ignores speed. Grouped subscriptions are not supported.",
    ),
  );
  o.default = "0";
  o.rmempty = false;
  o.depends({ connection_type: "proxy", proxy_config_type: "selector" });
  o.depends({ connection_type: "proxy", proxy_config_type: "selector_text" });
  o.depends({ connection_type: "proxy", proxy_config_type: "urltest" });
  o.depends({ connection_type: "proxy", proxy_config_type: "urltest_text" });
  o.depends({ connection_type: "proxy", proxy_config_type: "subscription" });

  o = section.taboption(
    "connection",
    form.Flag,
    "failover_direct",
    _("Go direct if all servers are down"),
    _(
      "When no server of this section answers (three checks in a row, at the check interval of the priority mode), its traffic goes out directly, where zapret or another tool for direct traffic can pick it up, and returns to the section as soon as a server answers. Every switch is written to the log. Off by default.",
    ),
  );
  o.default = "0";
  o.rmempty = true;
  o.depends("connection_type", "proxy");

  o = section.taboption(
    "connection",
    form.Flag,
    "geoip_flags",
    _("Detect country by IP (GeoIP)"),
    _(
      "For servers whose name has no flag, look the country up once by the server address and show its flag: in front of the name in a subscription (so grouping and the country filters work for it too), on the dashboard for your own links. The server addresses are sent to api.country.is over HTTPS; results are cached on the router.",
    ),
  );
  o.default = "0";
  o.rmempty = false;
  o.depends("connection_type", "proxy");

  o = section.taboption(
    "connection",
    form.Flag,
    "enable_udp_over_tcp",
    _("UDP over TCP"),
    _("Applicable for SOCKS and Shadowsocks proxy"),
  );
  o.default = "0";
  o.depends("connection_type", "proxy");
  o.rmempty = false;

  o = section.taboption(
    "connection",
    form.ListValue,
    "ipv6_dns_policy",
    _("IPv6 addresses of this section's domains"),
    _(
      "FakeIP: IPv6 goes through sing-box like IPv4, the same way as the section's IPv4 traffic. Real addresses: the domains of this section are answered with their real IPv6 addresses, so their IPv6 traffic goes out directly, outside the tunnel (their IPv4 traffic keeps the section's route). Needs IPv6 enabled in the settings.",
    ),
  );
  o.value("fakeip", _("FakeIP (same route as IPv4)"));
  o.value("real", _("Real addresses (IPv6 goes out directly)"));
  o.default = "fakeip";
  o.rmempty = false;
  o.depends("connection_type", "proxy");
  o.depends("connection_type", "vpn");
  o.depends("connection_type", "exclusion");

  // Writes the time of each server into its row of the list ("140 ms"), the way the
  // dashboard shows a server's latency; a best effort, the list below the button stays.
  const markRowTimes = (widget, optionName, rows) => {
    try {
      const times = new Map(rows.map((row) => [row.server, row.ms]));
      const root = widget.map.findElement("data-name", optionName);

      root?.querySelectorAll(".cbi-dynlist .item").forEach((item) => {
        const value = item.querySelector("input[type=hidden]")?.value ?? item.dataset.value;

        item.querySelector(".ns-dns-ms")?.remove();

        if (!times.has(value)) {
          return;
        }

        const ms = times.get(value);

        item.appendChild(
          E(
            "span",
            {
              class: "ns-dns-ms",
              style: `margin-left:.6em;font-weight:600;color:${ms === null ? "var(--error-color-medium, #dc3545)" : "var(--success-color-medium, #28a745)"}`,
            },
            ms === null ? _("no answer") : `${ms} ${_("ms")}`,
          ),
        );
      });
    } catch (_e) {
      // the list below the button is enough
    }
  };

  // DNS of this section only: until now the DNS was one list for every section.
  o = section.taboption(
    "connection",
    form.DynamicList,
    "own_dns_server",
    _("DNS servers of this section"),
    _(
      "Optional: DNS servers for this section only, instead of the global ones: scheme://host[:port][/path], where scheme is udp, tcp, dot, doh, doh3 or doq. A VPN or exclusion section resolves its direct connections through the first server; with real IPv6 addresses (above) all the servers answer the AAAA queries of its domains. A proxy section is resolved by its proxy server. Empty: the global DNS.",
    ),
  );
  Object.entries(main.DNS_POOL_PRESETS).forEach(([key, label]) => {
    o.value(key, label);
  });
  ["proxy", "vpn", "exclusion"].forEach((type) =>
    o.depends("connection_type", type),
  );
  o.rmempty = true;
  o.validate = function (section_id, value) {
    if (!value) {
      return true;
    }

    const validation = main.validateDnsPoolServer(value);

    return validation.valid ? true : validation.message;
  };

  o = section.taboption(
    "connection",
    form.ListValue,
    "own_dns_mode",
    _("Several DNS servers"),
    _(
      "How the servers of the list are used together when there are several. Needs sing-box 1.14 or newer; on an older core only the first server is used.",
    ),
  );
  o.value("fallback", _("Priority: next server if the previous one fails"));
  o.value("race", _("Parallel: the first usable answer wins"));
  o.value("single", _("First server only"));
  o.default = "fallback";
  ["proxy", "vpn", "exclusion"].forEach((type) =>
    o.depends("connection_type", type),
  );
  // the defaults are not written into every section that has no own DNS at all
  o.rmempty = true;
  o.cfgvalue = function (section_id) {
    return uci.get("netshift", section_id, "own_dns_mode") || "fallback";
  };

  o = section.taboption(
    "connection",
    form.Value,
    "own_dns_timeout",
    _("DNS server timeout"),
    _(
      "How long one DNS server may take before the next one is tried (priority) or its answer is dropped (parallel). Examples: 500ms, 2s",
    ),
  );
  ["proxy", "vpn", "exclusion"].forEach((type) =>
    o.depends("connection_type", type),
  );
  o.default = "2s";
  o.rmempty = true;
  o.cfgvalue = function (section_id) {
    return uci.get("netshift", section_id, "own_dns_timeout") || "2s";
  };
  o.validate = function (section_id, value) {
    const validation = main.validateDnsPoolTimeout(value);

    return validation.valid ? true : validation.message;
  };

  o = section.taboption(
    "connection",
    form.Flag,
    "own_dns_via_section",
    _("Ask these DNS servers through this section"),
    _(
      "The servers above are reached through the outbound of this section (a resolver that exists only inside the VPN or tunnel). If the outbound is not usable they are asked directly.",
    ),
  );
  o.default = "0";
  o.rmempty = true;
  o.depends("connection_type", "proxy");
  o.depends("connection_type", "vpn");

  // Speed of the servers above, from this router (the same test as in the settings).
  o = section.taboption(
    "connection",
    form.DummyValue,
    "_own_dns_speed",
    _("DNS speed test"),
    _(
      "Times every DNS server of the list (UDP, TCP, DoT and DoH; DoH3 and DoQ cannot be timed). Nothing is changed: use it to decide the order of the servers.",
    ),
  );
  o.rawhtml = true;
  ["proxy", "vpn", "exclusion"].forEach((type) =>
    o.depends("connection_type", type),
  );
  o.cfgvalue = function (section_id) {
    const widget = this;
    // not cbi-value-description: themes put a help icon in front of every such line
    const result = E("div", { style: "margin-top:.4em" });
    const button = E(
      "button",
      {
        class: "btn cbi-button",
        click: (ev) => {
          ev.preventDefault();

          // the live value of the list (as the filter preview reads it), unsaved servers included
          const element = widget.section.getUIElement(section_id, "own_dns_server");
          const value = element ? element.getValue() : [];
          const servers = (Array.isArray(value) ? value : [value]).filter(Boolean);

          if (!servers.length) {
            result.textContent = _("Add a DNS server above first");

            return;
          }

          button.disabled = true;
          result.textContent = _("Testing...");

          // timed the way the configuration sends them (through the section with
          // own_dns_via_section), not by the routes of the global DNS list
          main.NetShiftShellMethods.dnsBenchmark(["--section", section_id, ...servers])
            .then((reply) => {
              const rows = main.sortBySpeed(
                reply.success ? main.parseDnsBenchmark(reply.data) : [],
              );

              markRowTimes(widget, "own_dns_server", rows);
              result.replaceChildren(
                ...(rows.length
                  ? rows.map((row) =>
                      E("div", {}, [
                        `${row.server}: `,
                        row.ms === null ? _("no answer") : `${row.ms} ${_("ms")}`,
                      ]),
                    )
                  : [_("The test could not be run")]),
              );
            })
            .catch(() => {
              result.textContent = _("The test could not be run");
            })
            .finally(() => {
              button.disabled = false;
            });
        },
      },
      _("Test the servers"),
    );

    return E("div", {}, [button, result]);
  };

  o = section.taboption(
    "connection",
    form.Flag,
    "bypass_singbox",
    _("Bypass sing-box"),
    _(
      "The subnets of this exclusion section never enter sing-box: the router sends them out directly, which saves CPU, especially with Global Proxy. Only subnets and IP lists are bypassed; domains still pass through sing-box.",
    ),
  );
  o.default = "0";
  o.rmempty = false;
  o.depends("connection_type", "exclusion");

  o = section.taboption(
    "connection",
    form.Flag,
    "reality_mlkem",
    _("Reality: post-quantum key share (X25519MLKEM768)"),
    _(
      "Required by REALITY servers on Xray-core 26.9.8 or newer, which reject clients without it. Older servers may fail the handshake, so keep it off for them. Needs sing-box-extended 2.7.2 or newer and the chrome fingerprint; ignored on other cores",
    ),
  );
  o.default = "0";
  o.rmempty = false;
  if (!main.getCoreCapabilities().reality_mlkem) {
    o.description = `${o.description}. ${_("The installed core (%s) does not know this option, so it is ignored.").format(main.getCoreCapabilities().version)}`;
  }
  // Not offered for a hand-written outbound JSON (it carries its own TLS block)
  [
    "url",
    "selector",
    "urltest",
    "selector_text",
    "urltest_text",
    "subscription",
  ].forEach((type) =>
    o.depends({ connection_type: "proxy", proxy_config_type: type }),
  );

  o = section.taboption(
    "connection",
    form.Flag,
    "global_proxy",
    _("Global Proxy"),
    _("Route all unmatched traffic through this section's outbound.") +
      " " +
      _(
        "When enabled, traffic not matching any other section's lists will go through this proxy.",
      ) +
      " " +
      _("Use with Exclusion sections to route specific domains directly.") +
      " " +
      _("Only one section can be global at a time."),
  );
  o.default = "0";
  o.rmempty = false;
  // only a section with an outbound can take the unmatched traffic
  o.depends("connection_type", "proxy");
  o.depends("connection_type", "vpn");

  o = section.taboption(
    "connection",
    form.ListValue,
    "outbound_detour_section",
    _("Connect through another section"),
    _(
      "Chain the connection (double hop): this section's servers are reached through the outbound of the selected section. If the chain cannot be built, this section's traffic is rejected rather than sent directly.",
    ),
  );
  o.depends("connection_type", "proxy");
  o.rmempty = true;
  // One option object renders the widget of every section, so the list is the same
  // for all of them: enabled proxy/VPN sections. A section choosing itself is
  // refused by the validator instead.
  o.load = function () {
    const sections = this.map?.data?.state?.values?.netshift ?? {};

    this.keylist = [""];
    this.vallist = [_("Direct (no chaining)")];

    for (const secName in sections) {
      const sec = sections[secName];
      if (
        sec[".type"] === "section" &&
        sec["disabled"] !== "1" &&
        (sec["connection_type"] === "proxy" || sec["connection_type"] === "vpn")
      ) {
        this.keylist.push(secName);
        this.vallist.push(secName);
      }
    }

    return form.ListValue.prototype.load.apply(this, arguments);
  };
  o.validate = function (section_id, value) {
    if (value && value === section_id) {
      return _("A section cannot be chained through itself");
    }

    return true;
  };

  o = section.taboption(
    "connection",
    widgets.DeviceSelect,
    "interface",
    _("Network Interface"),
    _("Select network interface for VPN connection"),
  );
  o.depends("connection_type", "vpn");
  o.noaliases = true;
  o.nobridges = false;
  o.noinactive = false;
  o.filter = function (section_id, value) {
    // Blocked interface names that should never be selectable
    const blockedInterfaces = [
      "br-lan",
      "eth0",
      "eth1",
      "wan",
      "phy0-ap0",
      "phy1-ap0",
      "pppoe-wan",
      "lan",
    ];

    // Reject immediately if the value matches any blocked interface
    if (blockedInterfaces.includes(value)) {
      return false;
    }

    // Try to find the device object with the given name
    const device = this.devices.find((dev) => dev.getName() === value);

    // If no device is found, allow the value
    if (!device) {
      return true;
    }

    // Get the device type (e.g., "wifi", "ethernet", etc.)
    const type = device.getType();

    // Reject wireless-related devices
    const isWireless =
      type === "wifi" || type === "wireless" || type.includes("wlan");

    return !isWireless;
  };

  o = section.taboption(
    "connection",
    form.Flag,
    "domain_resolver_enabled",
    _("Domain Resolver"),
    _("Enable built-in DNS resolver for domains handled by this section"),
  );
  o.default = "0";
  o.rmempty = false;
  o.depends("connection_type", "vpn");

  o = section.taboption(
    "connection",
    form.ListValue,
    "domain_resolver_dns_type",
    _("DNS Protocol Type"),
    _("Select the DNS protocol type for the domain resolver"),
  );
  o.value("doh", _("DNS over HTTPS (DoH)"));
  o.value("dot", _("DNS over TLS (DoT)"));
  o.value("udp", _("UDP (Unprotected DNS)"));
  o.default = "udp";
  o.rmempty = false;
  o.depends({ connection_type: "vpn", domain_resolver_enabled: "1" });

  o = section.taboption(
    "connection",
    form.Value,
    "domain_resolver_dns_server",
    _("DNS Server"),
    _("Select or enter DNS server address"),
  );
  Object.entries(main.DNS_SERVER_OPTIONS).forEach(([key, label]) => {
    o.value(key, _(label));
  });
  o.default = "8.8.8.8";
  o.rmempty = false;
  o.depends({ connection_type: "vpn", domain_resolver_enabled: "1" });
  o.validate = function (section_id, value) {
    const validation = main.validateDNS(value);

    if (validation.valid) {
      return true;
    }

    return validation.message;
  };

  o = section.taboption(
    "routing",
    form.DynamicList,
    "community_lists",
    _("Community Lists"),
    _("Select a predefined list for routing") +
      ' <a href="https://github.com/itdoginfo/allow-domains" target="_blank">github.com/itdoginfo/allow-domains</a>',
  );
  o.placeholder = "Service list";
  Object.entries(main.DOMAIN_LIST_OPTIONS).forEach(([key, label]) => {
    o.value(key, _(label));
  });
  o.rmempty = true;
  let lastValues = [];
  let isProcessing = false;

  o.onchange = function (ev, section_id, value) {
    if (isProcessing) return;
    isProcessing = true;

    try {
      const values = Array.isArray(value) ? value : [value];
      let newValues = [...values];
      let notifications = [];

      const selectedRegionalOptions = main.REGIONAL_OPTIONS.filter((opt) =>
        newValues.includes(opt),
      );

      if (selectedRegionalOptions.length > 1) {
        const lastSelected =
          selectedRegionalOptions[selectedRegionalOptions.length - 1];
        const removedRegions = selectedRegionalOptions.slice(0, -1);
        newValues = newValues.filter(
          (v) => v === lastSelected || !main.REGIONAL_OPTIONS.includes(v),
        );
        notifications.push(
          E("p", {}, [
            E("strong", {}, _("Regional options cannot be used together")),
            E("br"),
            _(
              "Warning: %s cannot be used together with %s. Previous selections have been removed.",
            ).format(removedRegions.join(", "), lastSelected),
          ]),
        );
      }

      if (newValues.includes("russia_inside")) {
        const removedServices = newValues.filter(
          (v) => !main.ALLOWED_WITH_RUSSIA_INSIDE.includes(v),
        );
        if (removedServices.length > 0) {
          newValues = newValues.filter((v) =>
            main.ALLOWED_WITH_RUSSIA_INSIDE.includes(v),
          );
          notifications.push(
            E("p", { class: "alert-message warning" }, [
              E("strong", {}, _("Russia inside restrictions")),
              E("br"),
              _(
                "Warning: Russia inside can only be used with %s. %s already in Russia inside and have been removed from selection.",
              ).format(
                main.ALLOWED_WITH_RUSSIA_INSIDE.map(
                  (key) => main.DOMAIN_LIST_OPTIONS[key],
                )
                  .filter((label) => label !== "Russia inside")
                  .join(", "),
                removedServices.join(", "),
              ),
            ]),
          );
        }
      }

      if (JSON.stringify(newValues.sort()) !== JSON.stringify(values.sort())) {
        this.getUIElement(section_id).setValue(newValues);
      }

      notifications.forEach((notification) =>
        ui.addNotification(null, notification),
      );
      lastValues = newValues;
    } catch (e) {
      console.error("Error in onchange handler:", e);
    } finally {
      isProcessing = false;
    }
  };

  // --- Custom domains group (mode selector + the matching input below) ---
  // Three UCI keys kept (user_domain_list_type, user_domains,
  // user_domains_text); depends() shows only the input for the chosen mode,
  // so the trio reads as one "list-or-text" control.
  o = section.taboption(
    "routing",
    form.ListValue,
    "user_domain_list_type",
    _("Custom domains"),
    _(
      "Add your own domains: choose Dynamic List (one per row) or Text List (free-form), or Disabled to skip",
    ),
  );
  o.value("disabled", _("Disabled"));
  o.value("dynamic", _("Dynamic List"));
  o.value("text", _("Text List"));
  o.default = "disabled";
  o.rmempty = false;

  o = section.taboption(
    "routing",
    form.DynamicList,
    "user_domains",
    _("User Domains"),
    _(
      "Enter domain names without protocols, e.g. example.com or sub.example.com. Prefixes: full: (exact host), keyword: (part of the name), regex: (regular expression)",
    ),
  );
  o.placeholder = "Domains list";
  o.depends("user_domain_list_type", "dynamic");
  o.rmempty = false;
  o.validate = function (section_id, value) {
    // Optional
    if (!value || value.length === 0) {
      return true;
    }

    // validateDomainRule (not validateDomain): a routing rule matches a host,
    // never a URL path, so "example.com/path" is rejected here.
    const validation = main.validateDomainRule(value, true);

    if (validation.valid) {
      return true;
    }

    return validation.message;
  };

  o = section.taboption(
    "routing",
    form.TextValue,
    "user_domains_text",
    _("User Domains List"),
    _(
      "Enter domain names separated by commas, spaces, or newlines. You can add comments using //. Prefixes: full: (exact host), keyword: (part of the name), regex: (regular expression, no spaces or commas)",
    ),
  );
  o.placeholder =
    "example.com, sub.example.com\n// Social networks\ndomain.com test.com // personal domains\nfull:exact.example.org keyword:tracker regex:^ads[0-9]+\\.example\\.com$";
  o.depends("user_domain_list_type", "text");
  o.rows = 8;
  o.rmempty = false;
  o.validate = function (section_id, value) {
    // Optional
    if (!value || value.length === 0) {
      return true;
    }

    const domains = main.parseValueList(value);

    if (!domains.length) {
      return _(
        "At least one valid domain must be specified. Comments-only content is not allowed.",
      );
    }

    const { valid, results } = main.bulkValidate(domains, (row) =>
      main.validateDomainRule(row, true),
    );

    if (!valid) {
      const errors = results
        .filter((validation) => !validation.valid) // Leave only failed validations
        .map((validation) => `${validation.value}: ${validation.message}`); // Collect validation errors

      return [_("Validation errors:"), ...errors].join("\n");
    }

    return true;
  };

  // --- Custom subnets group (mode selector + the matching input below) ---
  // Same pattern as the domains group; keeps user_subnet_list_type,
  // user_subnets and user_subnets_text as separate UCI keys.
  o = section.taboption(
    "routing",
    form.ListValue,
    "user_subnet_list_type",
    _("Custom subnets"),
    _(
      "Add your own subnets or IPs: choose Dynamic List (one per row) or Text List (free-form), or Disabled to skip",
    ),
  );
  o.value("disabled", _("Disabled"));
  o.value("dynamic", _("Dynamic List"));
  o.value("text", _("Text List"));
  o.default = "disabled";
  o.rmempty = false;

  o = section.taboption(
    "routing",
    form.DynamicList,
    "user_subnets",
    _("User Subnets"),
    _(
      "Enter subnets in CIDR notation (e.g. 103.21.244.0/22) or single IP addresses",
    ),
  );
  o.placeholder = "IP or subnet";
  o.depends("user_subnet_list_type", "dynamic");
  o.rmempty = false;
  o.validate = function (section_id, value) {
    // Optional
    if (!value || value.length === 0) {
      return true;
    }

    const validation = main.validateSubnet(value);

    if (validation.valid) {
      return true;
    }

    return validation.message;
  };

  o = section.taboption(
    "routing",
    form.TextValue,
    "user_subnets_text",
    _("User Subnets List"),
    _(
      "Enter subnets in CIDR notation or single IP addresses, separated by commas, spaces, or newlines. " +
        "You can add comments using //",
    ),
  );
  o.placeholder =
    "103.21.244.0/22\n// Google DNS\n8.8.8.8\n1.1.1.1/32, 9.9.9.9 // Cloudflare and Quad9";
  o.depends("user_subnet_list_type", "text");
  o.rows = 10;
  o.rmempty = false;
  o.validate = function (section_id, value) {
    // Optional
    if (!value || value.length === 0) {
      return true;
    }

    const subnets = main.parseValueList(value);

    if (!subnets.length) {
      return _(
        "At least one valid subnet or IP must be specified. Comments-only content is not allowed.",
      );
    }

    const { valid, results } = main.bulkValidate(subnets, main.validateSubnet);

    if (!valid) {
      const errors = results
        .filter((validation) => !validation.valid) // Leave only failed validations
        .map((validation) => `${validation.value}: ${validation.message}`); // Collect validation errors

      return [_("Validation errors:"), ...errors].join("\n");
    }

    return true;
  };

  o = section.taboption(
    "routing",
    form.DynamicList,
    "local_domain_lists",
    _("Local Domain Lists"),
    _("Specify the path to the list file located on the router filesystem"),
  );
  o.placeholder = "/path/file.lst";
  o.rmempty = true;
  o.validate = function (section_id, value) {
    // Optional
    if (!value || value.length === 0) {
      return true;
    }

    const validation = main.validatePath(value);

    if (validation.valid) {
      return true;
    }

    return validation.message;
  };

  o = section.taboption(
    "routing",
    form.DynamicList,
    "local_subnet_lists",
    _("Local Subnet Lists"),
    _("Specify the path to the list file located on the router filesystem"),
  );
  o.placeholder = "/path/file.lst";
  o.rmempty = true;
  o.validate = function (section_id, value) {
    // Optional
    if (!value || value.length === 0) {
      return true;
    }

    const validation = main.validatePath(value);

    if (validation.valid) {
      return true;
    }

    return validation.message;
  };

  o = section.taboption(
    "routing",
    form.DynamicList,
    "remote_domain_lists",
    _("Remote Domain Lists"),
    _("Specify remote URLs to download and use domain lists"),
  );
  // Ready-made lists for a Block section (ads, trackers). Only .srs: sing-box reads them
  // itself and keeps them small; a plain text list of tens of thousands of domains is read
  // line by line by the router and is far too slow.
  o.value(
    "https://raw.githubusercontent.com/SagerNet/sing-geosite/rule-set/geosite-category-ads-all.srs",
    _("Ads and trackers (sing-geosite category-ads-all, for a Block section)"),
  );
  o.value(
    "https://raw.githubusercontent.com/SagerNet/sing-geosite/rule-set/geosite-category-ads.srs",
    _("Ads (sing-geosite category-ads, for a Block section)"),
  );
  o.value(
    "https://raw.githubusercontent.com/SagerNet/sing-geosite/rule-set/geosite-category-public-tracker.srs",
    _("BitTorrent public trackers (sing-geosite, for a Block section)"),
  );
  // The ready-made lists only block (ads, trackers): offered in a Block section only, and in any
  // other section only when it already uses one (so the value is still shown).
  o.renderWidget = function (section_id, option_index, cfgvalue) {
    const type =
      this.section.formvalue(section_id, "connection_type") ||
      uci.get("netshift", section_id, "connection_type");
    const parent = form.DynamicList.prototype.renderWidget;

    if (type === "block") {
      return parent.apply(this, arguments);
    }

    const used = Array.isArray(cfgvalue) ? cfgvalue : [cfgvalue];
    const keys = this.keylist;
    const values = this.vallist;
    const keep = keys
      .map((key, index) => [key, values[index]])
      .filter(([key]) => !REMOTE_BLOCK_LISTS.includes(key) || used.includes(key));

    this.keylist = keep.map(([key]) => key);
    this.vallist = keep.map(([, value]) => value);
    try {
      return parent.apply(this, arguments);
    } finally {
      this.keylist = keys;
      this.vallist = values;
    }
  };
  o.placeholder = "https://example.com/domains.srs";
  o.rmempty = true;
  o.validate = function (section_id, value) {
    // Optional
    if (!value || value.length === 0) {
      return true;
    }

    const validation = main.validateUrl(value);

    if (validation.valid) {
      return true;
    }

    return validation.message;
  };

  o = section.taboption(
    "routing",
    form.DynamicList,
    "remote_subnet_lists",
    _("Remote Subnet Lists"),
    _("Specify remote URLs to download and use subnet lists"),
  );
  o.placeholder = "https://example.com/subnets.srs";
  o.rmempty = true;
  o.validate = function (section_id, value) {
    // Optional
    if (!value || value.length === 0) {
      return true;
    }

    const validation = main.validateUrl(value);

    if (validation.valid) {
      return true;
    }

    return validation.message;
  };

  o = section.taboption(
    "routing",
    form.DynamicList,
    "fully_routed_ips",
    _("Fully Routed IPs"),
    _(
      "Specify local IP addresses or subnets whose traffic will always be routed through the configured route",
    ),
  );
  o.placeholder = "192.168.1.2 or 192.168.1.0/24";
  o.rmempty = true;
  o.depends("connection_type", "proxy");
  o.depends("connection_type", "vpn");
  o.validate = function (section_id, value) {
    // Optional
    if (!value || value.length === 0) {
      return true;
    }

    const validation = main.validateSubnet(value);

    if (validation.valid) {
      return true;
    }

    return validation.message;
  };

  o = section.taboption(
    "advanced",
    form.Flag,
    "disabled",
    _("Disable section"),
    _(
      "The section is completely ignored (routing, lists, subscriptions), but its settings are kept. Clear the checkbox to enable it again",
    ),
  );
  o.default = "0";
  o.rmempty = false;

  // A copy of this section under a new name, switched off: a copy that started at
  // once would take the same ports and the same lists as the original.
  o = section.taboption(
    "advanced",
    form.Button,
    "_duplicate",
    _("Duplicate this section"),
    _(
      "Makes a copy of the section with all its settings under a new name. The copy is switched off and has no Mixed Proxy, so nothing changes until you review and enable it. The copy is saved at once; Save and apply puts it into effect.",
    ),
  );
  o.inputtitle = _("Duplicate");
  o.inputstyle = "action";
  o.onclick = function (ev, section_id) {
    const names = uci.sections("netshift", "section").map((item) => item[".name"]);
    let name = `${section_id}_copy`;
    let counter = 2;

    while (names.includes(name)) {
      name = `${section_id}_copy${counter}`;
      counter += 1;
    }

    const source = uci.get("netshift", section_id);

    uci.add("netshift", "section", name);
    Object.keys(source)
      .filter((key) => !key.startsWith("."))
      .forEach((key) => uci.set("netshift", name, key, source[key]));
    uci.set("netshift", name, "disabled", "1");
    ["mixed_proxy_enabled", "mixed_proxy_port", "mixed_proxy_auth", "mixed_proxy_username", "mixed_proxy_password"].forEach(
      (key) => uci.unset("netshift", name, key),
    );

    return uci
      .save()
      .then(() => window.location.reload())
      .catch((error) => {
        ui.addNotification(
          null,
          E("p", _("Could not duplicate the section: %s").format(error.message || error)),
          "error",
        );
      });
  };

  o = section.taboption(
    "advanced",
    form.Flag,
    "mixed_proxy_enabled",
    _("Enable Mixed Proxy"),
    _(
      "Enable the mixed proxy, allowing this section to route traffic through both HTTP and SOCKS proxies",
    ),
  );
  o.default = "0";
  o.rmempty = false;
  o.depends("connection_type", "proxy");
  o.depends("connection_type", "vpn");

  o = section.taboption(
    "advanced",
    form.Value,
    "mixed_proxy_port",
    _("Mixed Proxy Port"),
    _(
      "Specify the port number on which the mixed proxy will run for this section. " +
        "Make sure the selected port is not used by another service",
    ),
  );
  o.default = "2080";
  o.placeholder = "2080";
  o.datatype = "port";
  o.rmempty = true;
  ["proxy", "vpn"].forEach((type) =>
    o.depends({ connection_type: type, mixed_proxy_enabled: "1" }),
  );

  o = section.taboption(
    "advanced",
    form.Flag,
    "mixed_proxy_auth",
    _("Require a login for the Mixed Proxy"),
    _(
      "Ask for a user name and a password. Without a login anyone in your network can use this proxy. If the login is not complete the proxy is not created at all.",
    ),
  );
  o.default = "0";
  o.rmempty = false;
  ["proxy", "vpn"].forEach((type) =>
    o.depends({ connection_type: type, mixed_proxy_enabled: "1" }),
  );

  o = section.taboption(
    "advanced",
    form.Value,
    "mixed_proxy_username",
    _("Mixed Proxy user name"),
  );
  o.rmempty = true;
  ["proxy", "vpn"].forEach((type) =>
    o.depends({ connection_type: type, mixed_proxy_enabled: "1", mixed_proxy_auth: "1" }),
  );
  o.validate = function (section_id, value) {
    if (!value) {
      return _("Enter a user name");
    }

    return /^[^\s:]+$/.test(value) || _("No spaces or colons in the user name");
  };

  o = section.taboption(
    "advanced",
    form.Value,
    "mixed_proxy_password",
    _("Mixed Proxy password"),
    _("Kept in the configuration file as it is typed."),
  );
  o.password = true;
  o.rmempty = true;
  ["proxy", "vpn"].forEach((type) =>
    o.depends({ connection_type: type, mixed_proxy_enabled: "1", mixed_proxy_auth: "1" }),
  );
  o.validate = function (section_id, value) {
    return value ? true : _("Enter a password");
  };

  o = section.taboption(
    "advanced",
    form.Flag,
    "resolve_real_ip_for_routing",
    _("Resolve real IP for routing"),
    _("Enable DNS resolve to get real IP when routing"),
  );
  o.default = "0";
  o.rmempty = false;
  o.depends("connection_type", "proxy");
  o.depends("connection_type", "vpn");
}

const EntryPoint = {
  createSectionContent,
};

return baseclass.extend(EntryPoint);
